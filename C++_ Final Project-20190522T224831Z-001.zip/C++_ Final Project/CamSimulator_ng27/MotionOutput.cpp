#include "MotionOutput.h"
#include <algorithm>
#include <sstream>

bool MotionOutput::readFile(ifstream & input)
{
	stringstream inStringStream;
	string inString;
	bool continueReading = true;
	double currAngle, currPos;

	// no longer needed since we have tail >> ShapeVertex *lastVertex = nullptr;
	while (!input.eof() && continueReading) {
		getline(input, inString);

		if (inString.find("End Motion") != string::npos)
			continueReading = false;
		else {
			// set up string stream
			inStringStream.str(inString);
			// read two numbers from stream (takes care of format and spacing)
			inStringStream >> currAngle >> currPos;
			// reset string stream so that it will read from start
			inStringStream.clear();
			// add point to end of list
			data.push_back({ currAngle, currPos });
		}

	}
	return true;
}

void MotionOutput::writeFile(ostream & output) const
{
	//for (int i = 0; i < data.size(); i++) {
	//	output << data[i].angle << "\t" << data[i].position << endl;
	//}

	for (auto &&curr : data) {
		output << curr.angle << "\t" << curr.position << endl;
	}
}
bool MotionOutput::compareData(PositionData left, PositionData right)
{
	return (left.angle < right.angle);
}

void MotionOutput::loadChart(System::Windows::Forms::DataVisualization::Charting::Series ^ aSeries,
	double camSpeed, int differential)

	
{
	vector<double> prevResults;
	vector<double> currResults;

	// load prevResults

	// add all data
	for (int i = 0; i < data.size(); i++) {
		prevResults.push_back(data[i].position);
	}

	// do derivation as needed
	if (differential == 0)
		currResults = prevResults;
	else {
		int pointCount = data.size();
		double timeIntervalPerDegree = camSpeed * 360. / 60.;
		for (int i = 0; i < differential; i++) {
			currResults.clear();
			for (int j = 0; j < pointCount - 1; j++) {
				currResults.push_back( (prevResults[j + 1] - prevResults[j])
					/ (timeIntervalPerDegree * (data[j + 1].angle - data[j].angle)));
				prevResults[j] = currResults[j];
			}
			// add last result (wrapping about 0 degrees)
			currResults.push_back( (prevResults.front() - prevResults.back()) 
				/ (timeIntervalPerDegree * (data.front().angle - (data.back().angle)-360.)));
			prevResults.back() = currResults.back();
		}
	}

	// add results to graph
	aSeries->Points->Clear();

	// calculate graph point at zero by interpolating
	double valueAtZero;
	double backAngle = data.back().angle - 360.;
	double deltaAngle = data.front().angle - backAngle;

	if (fabs(deltaAngle) > 1e-8) {
		// interpolate
		valueAtZero = currResults.back() + (-backAngle/deltaAngle) 
			* (currResults.front() - currResults.back()) ; 
	}
	else
		valueAtZero = currResults.front();

	// add graph point at zero (if needed)
	if (fabs(data[0].angle) > 1e-8) {
		aSeries->Points->AddXY(0., valueAtZero);
	}

	for (int i = 0; i < data.size(); i++) {
		aSeries->Points->AddXY(data[i].angle, currResults[i]);
		//CamSimulatorng27::MotionViewer viewer;
		//viewer.reloadCharts();
		//viewer.Refresh();
	}

	// add graph point at 360 (if needed)
	if (fabs(data.back().angle - 360.) > 1e-8)
		aSeries->Points->AddXY(360., valueAtZero);


}

double MotionOutput::getMaxPosition()
{
	double max_element = data[0].position;
	double min_element = data[0].position;
	for (int i = 1; i < data.size(); i++) {
		if (data[i].position < min_element)
		{
			min_element = data[i].position;
		}
		if (data[i].position > max_element)
		{
			max_element = data[i].position;
			max_element = data[i].position;
		}
	}
	return max_element;
}

bool MotionOutput::addData(PositionData newData)
{ // returns false if position in negative
	// replaces data if angle is already in use
	if (newData.position < 0)
		return false;
	else {
		//newData.angle = fmod(newData.angle, 360.);
		//if (newData.angle < 0)
		//	newData.angle += 360;

		if (data.empty()) {
			data.push_back(newData);
			return true;
		}

		// using vector functions while keeping the no duplicates criteria
		int foundItIndex = distance(data.begin(),
			lower_bound(data.begin(), data.end(), newData, compareData));
		//int foundItIndex = 1;
		if (foundItIndex >= data.size()) // nothing greater than given angle
			data.push_back(newData);
		else if (fabs(data[foundItIndex].angle - newData.angle) < 1e-8) // found duplicate
			data[foundItIndex].position = newData.position;
		else if (foundItIndex > 0 && fabs(data[foundItIndex - 1].angle - newData.angle) < 1e-8) // found duplicate
			data[foundItIndex - 1].position = newData.position;
		else
			data.insert(data.begin() + foundItIndex + 0, newData);

		// using vector sorting (the compare function must be static)
		// does not enforce no-duplicates criteria
		//data.push_back(newData);
		//sort(data.begin(), data.end(), compareData);

		int i = 0;
		// using linear search
		//if (newData.angle > data.back().angle)    // insert at end
		//	data.push_back(newData);
		//bool notFound = true;
		//while (notFound) {
		//	if (fabs(data[i].angle - newData.angle) < 1e-8) { // over-ride
		//		data[i].position = newData.position;
		//		notFound = false;
		//	}
		//	else if (newData.angle < data[i].angle) {   // insert new data
		//		data.insert(data.begin() + i, newData);
		//		notFound = false;
		//	}
		//	i++;
		//}

		// using binary search
		//if (newData.angle < data.front().angle)        // insert in front
		//	data.insert(data.begin(), newData);
		//else if (newData.angle >data.back().angle)    // insert at end
		//	data.push_back(newData);
		//else {                                         // insert in middle
		//	i = 0;
		//	int checkIndex;
		//	int minIndex = 0;
		//	int maxIndex = data.size() - 1;
		//	while (minIndex < maxIndex - 1) {
		//		checkIndex = (maxIndex + minIndex) / 2;
		//		if (newData.angle < data[checkIndex].angle)
		//			maxIndex = checkIndex;
		//		else if (newData.angle >= data[checkIndex].angle)
		//			minIndex = checkIndex;
		//		i++;                      // just to check algorithm performance
		//	}

		//	// special case of replacement of position value rather
		//	// than repeat of angle
		//	if (fabs(data[minIndex].angle - newData.angle) < 1e-8)
		//		data[minIndex].position = newData.position;
		//	else if (fabs(data[maxIndex].angle - newData.angle) < 1e-8)
		//		data[maxIndex].position = newData.position;
		//	else
		//		data.insert(data.begin() + minIndex+1, newData);
		//}

		// just to check algorithm performance
		//cout << " Checked " << i << " numbers out of " << data.size() << endl;
		return true;
	}
}

double MotionOutput::getPosition(double theta)
{
	if (!data.empty()) {
		// adjust theta
		theta = fmod(theta, 360.);
		if (theta < 0)
			theta += 360.;

		// look up interval using linear search
		double prevAngle = data.back().angle - 360.; // will interpolate around ends
		double prevPos = data.back().position;
		double currAngle;
		for (int i = 0; i < data.size(); i++) {
			currAngle = data[i].angle;
			if (prevAngle <= theta && theta <= currAngle) {
				return prevPos + (theta - prevAngle) / (currAngle - prevAngle)
					* (data[i].position - prevPos);
				// possible exit from function
			}
			prevAngle = currAngle;
			prevPos = data[i].position;
		}
		// look for interval using binary search >>> later

		// if the loops and searches returned no value, theta is on the last interval
		// prevAngle and prevPos are already set, so just return as needed
		return prevPos + (theta - prevAngle) / (data[0].angle + 360 - prevAngle)
			* (data[0].position - prevPos);
	}
	else
		return -1.;
}

ostream & operator<<(ostream & os, const MotionOutput & aMotion)
{
	aMotion.writeFile(os);
	return os;
}