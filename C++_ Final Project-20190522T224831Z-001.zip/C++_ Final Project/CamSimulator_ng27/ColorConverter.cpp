#include "ColorConverter.h"
#include <math.h>

System::Drawing::Color colorFromHSV(float hue, float saturation, float value)
{
	// using formula from:
	// https://www.rapidtables.com/convert/color/hsv-to-rgb.html

	// adjust H to be 0 <= H <= 360
	hue = fabs(fmod(hue, 360.));  // note that H=360 is the same as H=0

	double C = value * saturation;
	double X = C * (1 - fabs(fmod(hue / 60., 2) - 1));
	double m = value - C;
	double Rprime, Gprime, Bprime;

	if (hue < 60.) {
		Rprime = C;
		Gprime = X;
		Bprime = 0.;
	}
	else if (hue < 120.) {
		Rprime = X;
		Gprime = C;
		Bprime = 0.;
	}
	else if (hue < 180.) {
		Rprime = 0.;
		Gprime = C;
		Bprime = X;
	}
	else if (hue < 240.) {
		Rprime = 0.;
		Gprime = X;
		Bprime = C;
	}
	else if (hue < 300.) {
		Rprime = X;
		Gprime = 0.;
		Bprime = C;
	}
	else if (hue < 360.) {
		Rprime = C;
		Gprime = 0.;
		Bprime = X;
	}

	return System::Drawing::Color::FromArgb((Rprime + m)*255, 
		(Gprime + m) * 255, (Bprime + m) * 255);

}
