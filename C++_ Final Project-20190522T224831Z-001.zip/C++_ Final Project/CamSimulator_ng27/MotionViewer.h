#pragma once
#include "Follower.h"

namespace CamSimulatorng27 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MotionViewer
	/// </summary>
	public ref class MotionViewer : public System::Windows::Forms::Form
	{
	public:
		MotionViewer(Follower *aFollower)
		{
			theFollower = aFollower;
			InitializeComponent();
			reloadCharts();
			this->Refresh();
		}

		MotionViewer(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MotionViewer()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: Follower *theFollower = nullptr;
	private: System::Windows::Forms::DataVisualization::Charting::Chart^  positionChart;
	private: System::Windows::Forms::DataVisualization::Charting::Chart^  velocityChart;
	private: System::Windows::Forms::DataVisualization::Charting::Chart^  jerkChart;


	private: System::Windows::Forms::DataVisualization::Charting::Chart^  accelChart;

	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	protected:

	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::Windows::Forms::DataVisualization::Charting::ChartArea^  chartArea1 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::Series^  series1 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			System::Windows::Forms::DataVisualization::Charting::DataPoint^  dataPoint1 = (gcnew System::Windows::Forms::DataVisualization::Charting::DataPoint(0,
				0));
			System::Windows::Forms::DataVisualization::Charting::Series^  series2 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			System::Windows::Forms::DataVisualization::Charting::ChartArea^  chartArea2 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::Series^  series3 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			System::Windows::Forms::DataVisualization::Charting::DataPoint^  dataPoint2 = (gcnew System::Windows::Forms::DataVisualization::Charting::DataPoint(0,
				0));
			System::Windows::Forms::DataVisualization::Charting::ChartArea^  chartArea3 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::Series^  series4 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			System::Windows::Forms::DataVisualization::Charting::DataPoint^  dataPoint3 = (gcnew System::Windows::Forms::DataVisualization::Charting::DataPoint(0,
				0));
			System::Windows::Forms::DataVisualization::Charting::ChartArea^  chartArea4 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::Series^  series5 = (gcnew System::Windows::Forms::DataVisualization::Charting::Series());
			System::Windows::Forms::DataVisualization::Charting::DataPoint^  dataPoint4 = (gcnew System::Windows::Forms::DataVisualization::Charting::DataPoint(0,
				0));
			System::Windows::Forms::DataVisualization::Charting::ChartArea^  chartArea5 = (gcnew System::Windows::Forms::DataVisualization::Charting::ChartArea());
			System::Windows::Forms::DataVisualization::Charting::DataPoint^  dataPoint5 = (gcnew System::Windows::Forms::DataVisualization::Charting::DataPoint(0,
				0));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->positionChart = (gcnew System::Windows::Forms::DataVisualization::Charting::Chart());
			this->velocityChart = (gcnew System::Windows::Forms::DataVisualization::Charting::Chart());
			this->jerkChart = (gcnew System::Windows::Forms::DataVisualization::Charting::Chart());
			this->accelChart = (gcnew System::Windows::Forms::DataVisualization::Charting::Chart());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->positionChart))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->velocityChart))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->jerkChart))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->accelChart))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(16, 11);
			this->label1->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(167, 29);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Motion Viewer";
			// 
			// positionChart
			// 
			this->positionChart->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			chartArea1->AxisX->Crossing = 0;
			chartArea1->AxisX->Interval = 20;
			chartArea1->AxisX->IntervalOffsetType = System::Windows::Forms::DataVisualization::Charting::DateTimeIntervalType::Number;
			chartArea1->AxisX->IntervalType = System::Windows::Forms::DataVisualization::Charting::DateTimeIntervalType::Number;
			chartArea1->AxisX->IsLabelAutoFit = false;
			chartArea1->AxisX->LabelAutoFitMaxFontSize = 40;
			chartArea1->AxisX->MajorGrid->LineColor = System::Drawing::Color::Silver;
			chartArea1->AxisX->MajorTickMark->LineColor = System::Drawing::Color::LightGray;
			chartArea1->AxisX->Maximum = 360;
			chartArea1->AxisX->Minimum = 0;
			chartArea1->AxisX->TextOrientation = System::Windows::Forms::DataVisualization::Charting::TextOrientation::Horizontal;
			chartArea1->AxisX->Title = L"Degrees";
			chartArea1->AxisY->IsLabelAutoFit = false;
			chartArea1->AxisY->MajorGrid->LineColor = System::Drawing::Color::Silver;
			chartArea1->AxisY->MajorTickMark->Enabled = false;
			chartArea1->Name = L"ChartArea1";
			this->positionChart->ChartAreas->Add(chartArea1);
			this->positionChart->Location = System::Drawing::Point(15, 47);
			this->positionChart->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->positionChart->Name = L"positionChart";
			series1->ChartArea = L"ChartArea1";
			series1->ChartType = System::Windows::Forms::DataVisualization::Charting::SeriesChartType::Spline;
			series1->Color = System::Drawing::Color::Red;
			series1->MarkerBorderColor = System::Drawing::Color::Black;
			series1->MarkerSize = 4;
			series1->MarkerStyle = System::Windows::Forms::DataVisualization::Charting::MarkerStyle::Circle;
			series1->Name = L"Series1";
			series1->Points->Add(dataPoint1);
			series2->ChartArea = L"ChartArea1";
			series2->ChartType = System::Windows::Forms::DataVisualization::Charting::SeriesChartType::Point;
			series2->Name = L"Series2";
			this->positionChart->Series->Add(series1);
			this->positionChart->Series->Add(series2);
			this->positionChart->Size = System::Drawing::Size(773, 135);
			this->positionChart->TabIndex = 1;
			this->positionChart->Text = L"Position Chart";
			this->positionChart->UseWaitCursor = true;
			// 
			// velocityChart
			// 
			this->velocityChart->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			chartArea2->AxisX->Crossing = 0;
			chartArea2->AxisX->Interval = 20;
			chartArea2->AxisX->IntervalOffsetType = System::Windows::Forms::DataVisualization::Charting::DateTimeIntervalType::Number;
			chartArea2->AxisX->IntervalType = System::Windows::Forms::DataVisualization::Charting::DateTimeIntervalType::Number;
			chartArea2->AxisX->IsLabelAutoFit = false;
			chartArea2->AxisX->LabelAutoFitMaxFontSize = 40;
			chartArea2->AxisX->MajorGrid->LineColor = System::Drawing::Color::Silver;
			chartArea2->AxisX->MajorTickMark->LineColor = System::Drawing::Color::LightGray;
			chartArea2->AxisX->Maximum = 360;
			chartArea2->AxisX->Minimum = 0;
			chartArea2->AxisX->TextOrientation = System::Windows::Forms::DataVisualization::Charting::TextOrientation::Horizontal;
			chartArea2->AxisX->Title = L"Degrees";
			chartArea2->AxisY->IsLabelAutoFit = false;
			chartArea2->AxisY->MajorGrid->LineColor = System::Drawing::Color::Silver;
			chartArea2->AxisY->MajorTickMark->Enabled = false;
			chartArea2->Name = L"ChartArea1";
			this->velocityChart->ChartAreas->Add(chartArea2);
			this->velocityChart->Location = System::Drawing::Point(15, 231);
			this->velocityChart->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->velocityChart->Name = L"velocityChart";
			series3->ChartArea = L"ChartArea1";
			series3->ChartType = System::Windows::Forms::DataVisualization::Charting::SeriesChartType::Spline;
			series3->Color = System::Drawing::Color::RoyalBlue;
			series3->MarkerBorderColor = System::Drawing::Color::Black;
			series3->MarkerSize = 4;
			series3->MarkerStyle = System::Windows::Forms::DataVisualization::Charting::MarkerStyle::Circle;
			series3->Name = L"Series1";
			series3->Points->Add(dataPoint2);
			this->velocityChart->Series->Add(series3);
			this->velocityChart->Size = System::Drawing::Size(773, 135);
			this->velocityChart->TabIndex = 1;
			this->velocityChart->Text = L"Position Chart";
			this->velocityChart->UseWaitCursor = true;
			// 
			// jerkChart
			// 
			this->jerkChart->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			chartArea3->AxisX->Crossing = 0;
			chartArea3->AxisX->Interval = 20;
			chartArea3->AxisX->IntervalOffsetType = System::Windows::Forms::DataVisualization::Charting::DateTimeIntervalType::Number;
			chartArea3->AxisX->IntervalType = System::Windows::Forms::DataVisualization::Charting::DateTimeIntervalType::Number;
			chartArea3->AxisX->IsLabelAutoFit = false;
			chartArea3->AxisX->LabelAutoFitMaxFontSize = 40;
			chartArea3->AxisX->MajorGrid->LineColor = System::Drawing::Color::Silver;
			chartArea3->AxisX->MajorTickMark->LineColor = System::Drawing::Color::LightGray;
			chartArea3->AxisX->Maximum = 360;
			chartArea3->AxisX->Minimum = 0;
			chartArea3->AxisX->TextOrientation = System::Windows::Forms::DataVisualization::Charting::TextOrientation::Horizontal;
			chartArea3->AxisX->Title = L"Degrees";
			chartArea3->AxisY->IsLabelAutoFit = false;
			chartArea3->AxisY->MajorGrid->LineColor = System::Drawing::Color::Silver;
			chartArea3->AxisY->MajorTickMark->Enabled = false;
			chartArea3->Name = L"ChartArea1";
			this->jerkChart->ChartAreas->Add(chartArea3);
			this->jerkChart->Location = System::Drawing::Point(15, 601);
			this->jerkChart->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->jerkChart->Name = L"jerkChart";
			series4->ChartArea = L"ChartArea1";
			series4->ChartType = System::Windows::Forms::DataVisualization::Charting::SeriesChartType::Spline;
			series4->Color = System::Drawing::Color::Violet;
			series4->MarkerBorderColor = System::Drawing::Color::Black;
			series4->MarkerSize = 4;
			series4->MarkerStyle = System::Windows::Forms::DataVisualization::Charting::MarkerStyle::Circle;
			series4->Name = L"Series1";
			series4->Points->Add(dataPoint3);
			this->jerkChart->Series->Add(series4);
			this->jerkChart->Size = System::Drawing::Size(773, 135);
			this->jerkChart->TabIndex = 1;
			this->jerkChart->Text = L"Position Chart";
			this->jerkChart->UseWaitCursor = true;
			// 
			// accelChart
			// 
			this->accelChart->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			chartArea4->AxisX->Crossing = 0;
			chartArea4->AxisX->Interval = 20;
			chartArea4->AxisX->IntervalOffsetType = System::Windows::Forms::DataVisualization::Charting::DateTimeIntervalType::Number;
			chartArea4->AxisX->IntervalType = System::Windows::Forms::DataVisualization::Charting::DateTimeIntervalType::Number;
			chartArea4->AxisX->IsLabelAutoFit = false;
			chartArea4->AxisX->LabelAutoFitMaxFontSize = 40;
			chartArea4->AxisX->MajorGrid->LineColor = System::Drawing::Color::Silver;
			chartArea4->AxisX->MajorTickMark->LineColor = System::Drawing::Color::LightGray;
			chartArea4->AxisX->Maximum = 360;
			chartArea4->AxisX->Minimum = 0;
			chartArea4->AxisX->TextOrientation = System::Windows::Forms::DataVisualization::Charting::TextOrientation::Horizontal;
			chartArea4->AxisX->Title = L"Degrees";
			chartArea4->AxisY->IsLabelAutoFit = false;
			chartArea4->AxisY->MajorGrid->LineColor = System::Drawing::Color::Silver;
			chartArea4->AxisY->MajorTickMark->Enabled = false;
			chartArea4->Name = L"ChartArea1";
			this->accelChart->ChartAreas->Add(chartArea4);
			this->accelChart->Location = System::Drawing::Point(15, 416);
			this->accelChart->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->accelChart->Name = L"accelChart";
			series5->ChartArea = L"ChartArea1";
			series5->ChartType = System::Windows::Forms::DataVisualization::Charting::SeriesChartType::Spline;
			series5->Color = System::Drawing::Color::Green;
			series5->MarkerBorderColor = System::Drawing::Color::Black;
			series5->MarkerSize = 4;
			series5->MarkerStyle = System::Windows::Forms::DataVisualization::Charting::MarkerStyle::Circle;
			series5->Name = L"Series1";
			series5->Points->Add(dataPoint4);
			this->accelChart->Series->Add(series5);
			this->accelChart->Size = System::Drawing::Size(773, 135);
			this->accelChart->TabIndex = 1;
			this->accelChart->Text = L"Position Chart";
			this->accelChart->UseWaitCursor = true;
			// 
			// label2
			// 
			this->label2->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->ForeColor = System::Drawing::Color::RoyalBlue;
			this->label2->Location = System::Drawing::Point(675, 212);
			this->label2->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(107, 17);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Velocity (m/s)";
			this->label2->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// label3
			// 
			this->label3->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->label3->AutoSize = true;
			this->label3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label3->ForeColor = System::Drawing::Color::Red;
			this->label3->Location = System::Drawing::Point(719, 27);
			this->label3->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(66, 17);
			this->label3->TabIndex = 2;
			this->label3->Text = L"Position";
			this->label3->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// label4
			// 
			this->label4->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->label4->AutoSize = true;
			this->label4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label4->ForeColor = System::Drawing::Color::Green;
			this->label4->Location = System::Drawing::Point(603, 396);
			this->label4->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(174, 17);
			this->label4->TabIndex = 2;
			this->label4->Text = L"Acceleration (m/sec^2)";
			this->label4->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// label5
			// 
			this->label5->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Right));
			this->label5->AutoSize = true;
			this->label5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label5->ForeColor = System::Drawing::Color::Violet;
			this->label5->Location = System::Drawing::Point(665, 581);
			this->label5->Margin = System::Windows::Forms::Padding(4, 0, 4, 0);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(115, 17);
			this->label5->TabIndex = 2;
			this->label5->Text = L"Jerk (m/sec^3)";
			this->label5->TextAlign = System::Drawing::ContentAlignment::MiddleRight;
			// 
			// MotionViewer
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(804, 751);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->accelChart);
			this->Controls->Add(this->jerkChart);
			this->Controls->Add(this->velocityChart);
			this->Controls->Add(this->positionChart);
			this->Controls->Add(this->label1);
			this->Margin = System::Windows::Forms::Padding(4, 4, 4, 4);
			this->Name = L"MotionViewer";
			this->Text = L"MotionViewer";
			this->Resize += gcnew System::EventHandler(this, &MotionViewer::MotionViewer_Resize);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->positionChart))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->velocityChart))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->jerkChart))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->accelChart))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	public:	void setFollower(Follower *aFollower) {
		theFollower = aFollower;
	}

	public: void reloadCharts() {
		if (theFollower != nullptr && positionChart != nullptr) {
			// get data from follower and use it to populate chart series
			theFollower->showMotion(positionChart->Series->FindByName("Series1"));
			//theFollower->showMotion(positionChart->Series->FindByName("Series2"));
			theFollower->showMotion(velocityChart->Series->FindByName("Series1"), 1);
			theFollower->showMotion(accelChart->Series->FindByName("Series1"), 2);
			theFollower->showMotion(jerkChart->Series->FindByName("Series1"), 3);

		}
	}
	private: System::Void MotionViewer_Resize(System::Object^  sender, System::EventArgs^  e) {
		reloadCharts();
		this->Refresh();
	}
};
}
