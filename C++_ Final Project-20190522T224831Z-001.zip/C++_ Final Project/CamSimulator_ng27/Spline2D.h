#pragma once
#include "Shape2D.h"

class Spline2D : public Shape2D {
protected:
	//cli::array<System::Drawing::Point> ^pointArray;
	double splineTension = 0.5;
	
public:
	Spline2D() : Shape2D() {	};
	Spline2D(ifstream &input) : Shape2D(input) {	};

	virtual double getMaxRadius();
	virtual double getMinRadius();
	// for spline, these two values are not as simple as it is for shape

	virtual void paint(System::Drawing::Graphics ^g,
		System::Drawing::Color c = System::Drawing::Color::CornflowerBlue, 
		bool filled = false, bool showPoints = false);
	// over-rides the painting to create a spline instead of a polygon
	// certain color, filled or not, on the given geometric space.

	virtual Point2D getIntersection(double theta);
	// returns the coordinates of a point along the edge of
	// the spline that is the intersection between a ray drawn from coordinates 0, 0, 
	// along an angle theta.

	virtual void writeFile(ostream &output) const;
	// needed since friend functions cannot be virtual

protected:
	Point2D getIntersectionSpline(double theta, Point2D prev, Point2D curr, 
		Point2D next, Point2D nextNext);
	// finds intersection on spline by dividing spline segment into several straing-line
	// segments and using Shape2D to determine intersection on one of those segments

	Point2D getMinMaxRadius();
};