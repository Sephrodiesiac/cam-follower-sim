#pragma once

#include <string>
#include <msclr\marshal_cppstd.h>  //  needed for string conversions

using namespace std;

class StringPlus {
public:
	static string ltrim(string &inString) {
		auto firstNonSpace = inString.find_first_not_of(" ");
		if (firstNonSpace == -1)
			return "";
		else
			return inString.substr(firstNonSpace);
	}
	static string rtrim(string &inString) {
		return inString.substr(0, inString.find_last_not_of(" ") + 1);
	}
	static string trim(string &inString) {
		return ltrim(rtrim(inString));
	}
	static string convertString(System::String ^aString) {
		msclr::interop::marshal_context context;
		std::string standardString = context.marshal_as<std::string>(aString);
		return standardString;
	}
};