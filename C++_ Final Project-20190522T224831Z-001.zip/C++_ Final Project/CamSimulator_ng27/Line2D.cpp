#include "Line2D.h"
#include <math.h>

double Line2D::getLength(Point2D startPoint, Point2D endPoint)
{
	return getLength(startPoint.X, startPoint.Y, endPoint.X, endPoint.Y);
}

double Line2D::getLength(double startX, double startY, double endX, double endY)
{
	return sqrt(pow(startX - endX, 2) + pow(startY - endY, 2));
}

Point2D * Line2D::getIntersection(Point2D line1A, Point2D line1B, Point2D line2A, Point2D line2B)
{
	double x1 = line1A.X; double y1 = line1A.Y;
	double x2 = line1B.X; double y2 = line1B.Y;
	double x3 = line2A.X; double y3 = line2A.Y;
	double x4 = line2B.X; double y4 = line2B.Y;

	double denominator = (x1 - x2)*(y3 - y4) - (y1 - y2)*(x3 - x4);

	if (fabs(denominator) < TOLERANCE) // lines are parallel or coincident
		return nullptr;
	else {
		Point2D *newPoint = new Point2D;
		newPoint->X = ((x1 * y2 - y1 * x2)*(x3 - x4)
			- (x1 - x2)*(x3 * y4 - y3 * x4)) / denominator;
		newPoint->Y = ((x1 * y2 - y1 * x2)*(y3 - y4)
			- (y1 - y2)*(x3 * y4 - y3 * x4)) / denominator;

		return newPoint;
	}
}

bool Line2D::isbetween(Point2D pointA, Point2D pointB, Point2D pointC)
{
	return fabs(getLength(pointA, pointB)
		- getLength(pointA, pointC) - getLength(pointC, pointB)) < TOLERANCE;

}

double Line2D::getDirection(Point2D pointA, Point2D pointB)
{
	// get angle in radians between -PI/2 and PI/2 and convert to degrees
	double rootAngle = atan2(pointB.Y - pointA.Y, pointB.X - pointA.X) * 45. / atan(1.);

	if (rootAngle < 0)
		rootAngle += 360.;

	return rootAngle;
}

Point2D Line2D::rotate(Point2D givenPoint, Point2D aboutPoint, double theta)
{
	double deltaX = givenPoint.X - aboutPoint.X;
	double deltaY = givenPoint.Y - aboutPoint.Y;
	theta *= atan(1.) / 45.; // convert to radians

	double newX = aboutPoint.X + deltaX * cos(theta) - deltaY * sin(theta);
	double newY = aboutPoint.Y + deltaX * sin(theta) + deltaY * cos(theta);

	return { newX, newY };
}
