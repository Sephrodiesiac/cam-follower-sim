/*
Comment, comment, comment
*/
#pragma once

#define TOLERANCE 1e-10

struct Point2D {
	double X;
	double Y;
};


class Line2D {
public:
	static double getLength(Point2D startPoint, Point2D endPoint);
		//returns the distance from one point to the other.

	static double getLength(double startX, double startY,
		double endX, double endY);
		//returns the distance from one point to the other.

	static Point2D *getIntersection(Point2D line1A, Point2D line1B, Point2D
		line2A, Point2D line2B);
		//returns a newly created point at the intersection of the two lines
		//defined by the two end points.Note that the intersection point may lie beyond the given line
		//segments (i.e., the two line segments may not touch at all, but their extensions into infinity will
		//surely intersect).If the lines are parallel, the function returns nullptr

	static bool isbetween(Point2D pointA, Point2D pointB, Point2D pointC);
	// returns true if point C is exactly between points A and B

	static double getDirection(Point2D pointA, Point2D pointB);

	static Point2D rotate(Point2D givenPoint, Point2D aboutPoint, double theta);
	// calculates and returns coordinates of given point rotated about point by 
	// an angle of theta.

	static Point2D rotate(Point2D givenPoint, double theta) {
		return rotate(givenPoint, { 0., 0. }, theta);
	};
	// calculates and returns coordinates of given point rotated about 0,0 by 
	// an angle of theta.
};