#include "Spline2D.h"
#include <algorithm>
#include <sstream>

double Spline2D::getMinRadius()
{
	return getMinMaxRadius().X;
}

double Spline2D::getMaxRadius()
{
	return getMinMaxRadius().Y;
}

Point2D Spline2D::getMinMaxRadius()
{
	double minRad = 0., maxRad = 0.;
	double currRad;
	double angleStep = 1.;
	Point2D currIntersect;
	for (int currAngle = 0; currAngle < 360.; currAngle += angleStep) {
		currIntersect = getIntersection(currAngle);
		currRad = Line2D::getLength({ 0.,0. }, currIntersect);
		if (currAngle == 0. || currRad < minRad)
			minRad = currRad;
		if (currRad > maxRad)
			maxRad = currRad;
	}

	return { minRad, maxRad };
}

void Spline2D::paint(System::Drawing::Graphics ^ g, System::Drawing::Color c,
	bool filled, bool showPoints)
{
	using namespace System::Drawing;
	if (head != nullptr) {

		ShapeVertex *currVertex = head;
		float adj = 1000.;
		float s = 10;

		//create and load up a cli::array of points
		cli::array<Point> ^ pointArray = gcnew cli::array<Point>(vertexCount);
		int i = 0;
		while (currVertex != nullptr) {
			pointArray[i++] = Point(currVertex->thePoint.X * adj, currVertex->thePoint.Y*adj);
			currVertex = currVertex->next;
		}
		// draw
		Pen^ thePen = gcnew Pen(c, maxRadius / 50.*adj);
		g->ScaleTransform(1. / adj, 1. / adj);
		g->DrawClosedCurve(thePen, pointArray,
			splineTension, Drawing2D::FillMode::Winding); // winding parameter is needed but ignored
		
		if (showPoints) {
			Pen^ pointPen = gcnew Pen(Color::Green, 0.0);
			float pointDiam = maxRadius / 25.*adj;
			for (int i = 0; i < vertexCount; i++)
				g->DrawEllipse(pointPen, pointArray[i].X - pointDiam / 2.f,
					pointArray[i].Y	 - pointDiam / 2.f, pointDiam, pointDiam);
		}

		g->ScaleTransform(adj, adj);
	}
}

Point2D Spline2D::getIntersection(double theta)
{
	if (head != nullptr && vertexCount > 3) { // cannot calculate splines with less than 4 pnts
		// adjust theta
		theta = fmod(theta, 360.);
		if (theta < 0)
			theta += 360;
		Point2D *intersect;
		Point2D origin = { 0., 0. };

		// need to keep track of four points
		ShapeVertex *prevVertex = tail;
		ShapeVertex *currVertex = head;
		ShapeVertex *nextVertex, *nextNextVertex;

		bool continueLoop = true, foundCandidate;
		double currDirection, nextDirection, minDirection, maxDirection;

		// find segment such that wanted angle is between the two vertices
		while (currVertex != nullptr && continueLoop) {
			nextVertex = currVertex->next;
			if (nextVertex == nullptr)
				nextVertex = head;

			currDirection = Line2D::getDirection(origin, currVertex->thePoint);
			nextDirection = Line2D::getDirection(origin, nextVertex->thePoint);
			minDirection = min(currDirection, nextDirection);
			maxDirection = max(currDirection, nextDirection);

			// BIG PROBLEM WITH DETERMINING IF THETA IS BETWEEN THE TWO DIRECTIONS

			foundCandidate = false;
			if (minDirection < 90. && maxDirection > 270)  // first and fourth quadrants
				foundCandidate = theta <= minDirection || theta >= maxDirection;
			else
				foundCandidate = minDirection <= theta && theta <= maxDirection;

			if (foundCandidate) {
				// found segment, first check to see if there's an easy answer
				// may not be needed
				if (fabs(currDirection - theta) < TOLERANCE)
					return currVertex->thePoint;
				else if (fabs(nextDirection - theta) < TOLERANCE)
					return nextVertex->thePoint;
				else {
					// set up nextNext (for spline control points)

					nextNextVertex = nextVertex->next;
					if (nextNextVertex == nullptr)
						nextNextVertex = head;

					// get intersection by calling more detailed function
					return getIntersectionSpline(theta, prevVertex->thePoint, currVertex->thePoint,
						nextVertex->thePoint, nextNextVertex->thePoint);
				}
			}

			prevVertex = currVertex;
			currVertex = currVertex->next;
		}
	}
	else {
		Point2D intersect = { 0.,0. };
		return intersect;
	}
}

void Spline2D::writeFile(ostream & output) const
{
	output << "Spline ";
	Shape2D::writeFile(output);
}

Point2D Spline2D::getIntersectionSpline(double theta, Point2D prev,
	Point2D curr, Point2D next, Point2D nextNext)
{
	// load up a shape with a ton of intermediate points on the given spline segment
	Shape2D tempShape;

	// get coefficients
	float c = splineTension;  // equations were set up using "c"

	float xa = -c * prev.X + (2. - c)*curr.X
		+ (c - 2.)*next.X + c * nextNext.X;
	float xb = 2.*c*prev.X + (c - 3.)*curr.X
		+ (3. - 2.*c)*next.X - c * nextNext.X;
	float xc = -c * prev.X + c * next.X;
	float xd = curr.X;

	float ya = -c * prev.Y + (2. - c)*curr.Y
		+ (c - 2.)*next.Y + c * nextNext.Y;
	float yb = 2.*c*prev.Y + (c - 3.)*curr.Y
		+ (3. - 2.*c)*next.Y - c * nextNext.Y;
	float yc = -c * prev.Y + c * next.Y;
	float yd = curr.Y;

	int divisions = 20;
	double t, x, y;
	for (int k = 1; k <= divisions; k++) {
		t = float(k) / divisions;  // parameter
		x = xa * t*t*t + xb * t*t + xc * t + xd;
		y = ya * t*t*t + yb * t*t + yc * t + yd;
		tempShape.addPoint(x, y, divisions + 2);
	}

	// need to add the first point at the end so that Shape2D::getIntersection()
	// won't check the straight edge first
	tempShape.addPoint(curr, divisions + 4);

	// call Shape2D::getIntersection() with detailed curve
	return tempShape.getIntersection(theta);
}
