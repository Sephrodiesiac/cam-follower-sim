#pragma once

// copy these comments to the top of the interface .h file

// using flickerless panel makes the form design view not work.
// to use flickerless panel or allow the design view, use one of these
// in InitComponents() function
//    for design view >>>>    this->mainPanel = (gcnew System::Windows::Forms::Panel());
//    for flickerless >>>>    this->mainPanel = (gcnew FlickerLessPanel());


ref class FlickerLessPanel : public System::Windows::Forms::Panel
{

public: FlickerLessPanel()
{
	this->DoubleBuffered = true;
}
};
