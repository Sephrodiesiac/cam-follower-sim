/*
		   __
.-.__      \ .-.  ___  __
|_|  '--.-.-(   \/\;;\_\.-._______.-.           Nestor Gomez
(-)___     \ \ .-\ \;;\(   \       \ \          Carnegie Mellon University
 \,   '---._\_((Q)) \;;\\ .-\     __(_)         C++ for Engineers, 24-280A
  \          __'-' / .--.((Q))---'   \,         Problem Set 3.  Due Tues. Feb. 12, 2019
   '   ___.-:    \|  |   \'-'_         \
	.-'      \ .-.\   \   \ \ '--.__    '\
	|____.----((Q))\   \__|--\_      \    '     The Shape2D class is used to model
	(_)        '-'  \_  :  \-' '--.___\         a planar shape composed of a series of
	 \,               \  \  \       \(_)        vertices connected by straight line
	  \                \  \  \       \,         segments. The last segment is assumed
	   '\               \  \  \        \        to go from last vertex to first vertex
						 \  \__|        '
						  \_:.  \               The vertices are maintained in a linked
							\ \  \              list while maintaining a head and tail.
							 \ \  \             Given a 2D point, the shape can
							  \_\_|             determine if it is inside or outside.
*/

#pragma once
#include <iostream>
#include <fstream>
#include "Line2D.h"

using namespace std;
//using namespace System::Drawing;

struct ShapeVertex { // for linked list implementation
	Point2D thePoint;
	ShapeVertex *next;
};

class Shape2D {
protected:
	ShapeVertex *head, *tail; // tail will make it easy to add at end
	int vertexCount;
	double minX, minY, maxX, maxY; // used by the isContained function
	double maxRadius, minRadius;   // used by Cam class

public:
	Shape2D();
	//default constructor for the class. Initializes member variables only.

	Shape2D(ifstream &input);
	//additional constructor for the class.Takes a pre - created
	//ifstream and uses it to read coordinate information for the shape.Note that the method�s parameter
	//cannot be a string filename because the file may already be in the process of being read.The
	//constructor needs to instantiate any constituent objects and/or data structures.
	
	~Shape2D();
	//destructor for the class

	bool readFile(ifstream &input);
	//clears all data and reads new data from a file

	bool addPoint(Point2D newPoint, int index);
	//adds a coordinate point such that
	//the new point becomes the index-th point.For example, an index value of 3 will insert a point
	//between the existing 2nd and 3rd points such that the new point becomes the new 3rd point.An index
	//of 1will insert the new point at the start of the shape and an index greater than the number of points
	//will insert the new point as the last point.Function returns false only if the new point cannot be
	//added for any reason.

	bool addPoint(double newX, double newY, int index);
	//creates a coordinate
	//point with the given coordinates and inserts it into the path such that the new point becomes the
	//index - th point.Otherwise similar to the above.

	bool removePoint(int index);
	//removes the indicated point from the shape.Function
	//returns false only if the point cannot be removed for any reason.

	double perimeter();
	//calculates and returns the length of the perimeter of the shape.

	virtual void writeFile(ostream &output) const;
	// needed since friend functions cannot be virtual
	// note that the "const" assures that this function does not change any member variables

	friend ostream & operator << (ostream& os, const Shape2D &aShape);
	// used to output all the coordinates of a shape.

	bool isContained(Point2D testPoint, bool isInclusive);
	//returns true if the coordinates of testPoint is contained inside the shape.
	//If isInclusive is true, then a testPoint right on the shape
	//outline itself is considered inside.

	bool isContained(double testX, double testY, bool isInclusive);
	//same as above, just a different interface.

	virtual void paint(System::Drawing::Graphics ^g,
		System::Drawing::Color c = System::Drawing::Color::CornflowerBlue, 
		bool filled = false, bool showPoints = false);
	// generates the geometry of the shape, of a
	//certain color, filled or not, on the given geometric space.

	virtual Point2D getIntersection(double theta);
	// returns the coordinates of a point along the edge of
	// the shape that is the intersection between a ray drawn from coordinates 0, 0, along an angle theta.

	virtual double getMaxRadius() { return maxRadius; };
	virtual double getMinRadius() { return minRadius; };


protected:
	void resetMinMax();
	//this is a protected function that goes through the list of vertices and determines
	//the �bounding box� of the shape by setting the member variables minX, minY, maxX, and maxY.
	//also does minRadius and maxRadius

	void updateMinMax(double currX, double currY);
	//updates the values of min/max X and Y as needed based on currX and currY

	void deleteAndReset();
	//completely deletes all of the shape's vertices and resets all parameters


};