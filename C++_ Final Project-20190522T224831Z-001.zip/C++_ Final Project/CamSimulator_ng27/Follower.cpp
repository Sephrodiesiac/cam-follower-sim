#include <sstream>
#include "Follower.h"
#include "StringPlus.h"
#include "ColorConverter.h"
#include <time.h>

bool Follower::readFile(ifstream & input)
{
	srand(time(NULL));

	bool foundFollower = false; // just to be sure a folloer file is being read
	stringstream inStringStream;
	double currX, currY;

	string inString;
	int colonLocation;

	while (!input.eof()) {
		getline(input, inString);
		colonLocation = inString.find(":");

		if (inString.find("Cam:") != string::npos) {
			foundFollower = true;
		}
		else if (inString.find("followerID:") != string::npos) {
			foundFollower = true;
			followerID = StringPlus::trim(inString.substr(colonLocation + 1));
		}
		else if (inString.find("stepSize:") != string::npos) {
			// assume value is good, may add more robustness later
			stepSize = stod(inString.substr(colonLocation + 1));
		}
		else if (inString.find("Point:") != string::npos) {
			// set up string stream
			inStringStream.str(inString.substr(colonLocation + 1));
			// read two numbers from stream (takes care of format and spacing)
			inStringStream >> currX >> currY;
			// reset string stream so that it will read from start
			inStringStream.clear();
			// add data
			if (inString.find("start") != string::npos)
				startPoint = { currX, currY };
			else if (inString.find("end") != string::npos)
				endPoint = { currX, currY };
		}
		else if (inString.find("Motion") != string::npos) {
			// create the motion output object using input stream as constructor parameter
			if (itsMotion != nullptr)
				delete itsMotion;

			itsMotion = new MotionOutput(input);
		}
	}
	return foundFollower;
}

void Follower::writeFile(ofstream & output)
{
	output << "Follower:" << endl;

	output << "followerID: " << followerID << endl;
	output << "startPoint: " << startPoint.X << "\t" << startPoint.Y << endl;
	output << "endPoint: " << endPoint.X << "\t" << endPoint.Y << endl;
	output << "stepSize: " << stepSize << endl;
	output << "Motion:" << endl;
	if (itsMotion != nullptr)
		itsMotion->writeFile(output);
	output << "End Motion:" << endl;

}

void Follower::setCam(Cam * aCam)
{
	if (aCam != nullptr) {

		itsCam = aCam;
		length = (itsCam->getLargestRadius() - itsCam->getSmallestRadius())
			* 1.7;
	}
}

void Follower::generateMotion()
{
	if (itsCam != nullptr) {
		// reset and prepare for motion generation
		double oldCamAngle = itsCam->getCurrAngle();
		itsCam->reset();
		delete itsMotion;
		itsMotion = new MotionOutput();

		// get follower orientation
		double orientation = getOrientation();
		double minRadius = itsCam->getSmallestRadius();
		double currLength;

		double currAngle;
		if (stepSize < 0)
			currAngle = 360.;
		else
			currAngle = 0.;

		Point2D currTrackPoint;
		while (0. <= currAngle && currAngle <= 360.) {
			currTrackPoint = itsCam->step(this, stepSize);
			currLength = Line2D::getLength({ 0,0 }, currTrackPoint) - minRadius;
			itsMotion->addData({ currAngle, currLength });
			currAngle += stepSize;
		}

		// reset the cam to its original currAngle;
		itsCam->reset();
		itsCam->setCurrAngle(oldCamAngle);
	}
}

void Follower::clearMotion()
{
	delete itsMotion;
}

void Follower::paint(System::Drawing::Graphics ^ g)
{
	// only paint if numbers make sense
	if (itsCam != nullptr && startPoint.X > -1e6 && endPoint.X > -1e6) {

		// checking addData
		//if (itsMotion != nullptr)
		//	itsMotion->addData({ rand() % 380 - 10., 3.456 });
		//itsMotion->addData({ (double)rand() / RAND_MAX * 380. - 10., 3.456 });

		// get follower orientation
		double orientation = getOrientation();

		// get position of follower head
		Point2D loc = itsCam->getTrackPoint(orientation);

		// adjust drawing space
		float adj = 1000.;
		g->ScaleTransform(1. / adj, 1. / adj);
		g->TranslateTransform(loc.X * adj, loc.Y * adj);
		g->RotateTransform(orientation);

		// get display sizes of follower
		float adjLength = length * adj;
		float height = adjLength * 0.065;
		float tipSlope = 1.2;

		// draw follower
		using namespace System::Drawing;
		Pen ^mainPen = gcnew Pen(Color::Black, 0.0);
		g->DrawLine(mainPen, 0.f, 0.f, height * tipSlope, height / 2.);
		g->DrawLine(mainPen, height * tipSlope, height / 2., adjLength, height / 2.);

		g->DrawLine(mainPen, 0.f, 0.f, height * tipSlope, -height / 2.);
		g->DrawLine(mainPen, height * tipSlope, -height / 2., adjLength, -height / 2.);
		g->DrawLine(mainPen, adjLength, height / 2., adjLength, -height / 2.);

		// draw gliders
		float glidePosition = (itsCam->getLargestRadius() * 1.1
			- Line2D::getLength(0, 0, loc.X, loc.Y)) * adj;
		float glideElev = height * 0.75;
		float glideHeight = height * 0.5;
		float glideLength = adjLength * 0.25;
		int ballCount = 6;
		float ballDiam = glideLength / (ballCount + 2);
		float currPos = glidePosition + glideLength / ballCount / 2.;

		for (int i = 0; i < ballCount; i++) {
			g->DrawEllipse(mainPen, currPos - ballDiam / 2., glideElev - ballDiam / 2.,
				ballDiam, ballDiam);
			g->DrawEllipse(mainPen, currPos - ballDiam / 2., -glideElev - ballDiam / 2.,
				ballDiam, ballDiam);
			currPos += glideLength / ballCount;
		}
		g->FillRectangle(Brushes::LightGray, glidePosition, glideElev, glideLength, glideHeight);
		g->FillRectangle(Brushes::LightGray, glidePosition, -glideElev - glideHeight, glideLength, glideHeight);

		// adjust drawing space back to normal
		g->RotateTransform(-orientation);
		g->TranslateTransform(-loc.X * adj, -loc.Y * adj);
		g->ScaleTransform(adj, adj);

	}
}

void Follower::showMotion(System::Windows::Forms::DataVisualization::Charting::Series ^ aSeries,
	int differential)
{
	// call MotionOutput
	if (itsMotion != nullptr) {
		double currCamSpeed = 30.;
		MotionOutput *motion = getMotion();
		if (itsCam != nullptr)
			currCamSpeed = itsCam->getCamSpeed();

		itsMotion->loadChart(aSeries, currCamSpeed, differential);
	}

}

double Follower::getOrientation()
{
	return atan2((startPoint.Y - endPoint.Y), (startPoint.X - endPoint.X))
		* 45. / atan(1.);
}

MotionOutput * Follower::getMotion()
{
	return itsMotion;
}

