#include "Shape2D.h"
#include <sstream>
#include <math.h>
#include <algorithm>

Shape2D::Shape2D()
{
	head = nullptr;
	deleteAndReset();
}

Shape2D::Shape2D(ifstream &input)
{
	head = nullptr;
	readFile(input);
}

bool Shape2D::readFile(ifstream &input)
{
	stringstream inStringStream;
	string inString;
	bool continueReading = true;
	double currX, currY;

	// initialize variables
	deleteAndReset();

	// no longer needed since we have tail >> ShapeVertex *lastVertex = nullptr;
	while (!input.eof() && continueReading) {
		getline(input, inString);

		if (inString.find("End Shape") != string::npos)
			continueReading = false;
		else {
			// set up string stream
			inStringStream.str(inString);
			// read two numbers from stream (takes care of format and spacing)
			inStringStream >> currX >> currY;
			// reset string stream so that it will read from start
			inStringStream.clear();
			// add point to end of list
			addPoint(currX, currY, vertexCount + 1);
		}

	}
	return true;
}


Shape2D::~Shape2D()
{
	deleteAndReset();
}

bool Shape2D::addPoint(Point2D newPoint, int index)
{
	return addPoint(newPoint.X, newPoint.Y, index);
}

bool Shape2D::addPoint(double newX, double newY, int index)
{
	if (index <= 0)
		return false;
	else {

		// create a new vertex
		ShapeVertex *newVertex = new ShapeVertex;
		// initialize explicitly (works always)
		//newVertex->thePoint.X = newX;
		//newVertex->thePoint.Y = newY;
		//newVertex->next = nullptr;

		// initialize semi-implicitly (works in later versions of C/C++)
		//newVertex->thePoint = { newX, newY };
		//newVertex->next = nullptr;

		// initialize implicitly (note the use of the *)
		*newVertex = { {newX, newY}, nullptr };

		// figure out where to put the new vertex
		if (index == 1 || head == nullptr) { // add at head
			if (head == nullptr) {
				head = tail = newVertex;
				minX = maxX = newX;
				minY = maxY = newY;
				minRadius = maxRadius = -1;
			}
			else {
				newVertex->next = head;
				head = newVertex;
			}
		}
		else if (index > vertexCount) { // add at tail (obviously tail != nullptr)
			tail->next = newVertex;
			tail = newVertex;
		}
		else { // add in the middle (need while loop)

			int currIndex = 1;
			ShapeVertex *currVertex = head;

			// note that I need to be 1 vertex "behind" in order to insert in correct spot
			// for example, to insert in number 7 spot, I need to stop when currIndex is 6
			while (currVertex != nullptr && currIndex < index - 1) {
				currVertex = currVertex->next;
				currIndex++;
			}
			newVertex->next = currVertex->next;
			currVertex->next = newVertex;
		}

		// finish up
		updateMinMax(newX, newY);
		vertexCount++;

		return true;
	}
}

bool Shape2D::removePoint(int index)
{
	if (index <= 0 || index > vertexCount || head == nullptr)
		return false;
	else {
		ShapeVertex *oldVertex;

		if (index == 1) { // remove at head
			oldVertex = head;
			head = oldVertex->next;
		}
		else {
			int currIndex = 1;
			ShapeVertex *currVertex = head;

			// note that I need to be 1 vertex "behind" in order to remove correctly
			// for example, to remove the number 7 spot, I need to stop when currIndex is 6
			// so I can make 6 refer to 8
			while (currVertex != nullptr && currIndex < index - 1) {
				currVertex = currVertex->next;
				currIndex++;
			}
			oldVertex = currVertex->next;
			currVertex->next = oldVertex->next;
			if (tail == oldVertex) // can compare pointers
				tail = currVertex;
		}

		// finish up
		delete oldVertex;  // release memory allocated through "new"
		resetMinMax();     // needed since there's no way to know
		vertexCount--;
		return true;
	}
}

double Shape2D::perimeter()
{
	double perim = 0.0;

	if (head != nullptr) {
		ShapeVertex *currVertex, *prevVertex;
		prevVertex = head;
		currVertex = head->next;
		while (currVertex != nullptr) {
			perim += Line2D::getLength(prevVertex->thePoint, currVertex->thePoint);
			prevVertex = currVertex;
			currVertex = currVertex->next;
		}
		// add in last shape side
		perim += Line2D::getLength(prevVertex->thePoint, head->thePoint);

	}

	return perim;
}

bool Shape2D::isContained(Point2D testPoint, bool isInclusive)
{
	return isContained(testPoint.X, testPoint.Y, isInclusive);
}

bool Shape2D::isContained(double testX, double testY, bool isInclusive)
{
	if (vertexCount < 2) // not enough vertices
		return false;
	else if (!(minX <= testX && testX <= maxX && minY <= testY && testY <= maxY))
		return false;
	else {
		bool tooHigh, tooLow, tooLeft;
		ShapeVertex *currVertex = head;
		int crossCount = 0;
		double segX1, segY1, segX2, segY2, crossX;

		// set first vertix of segment
		segX1 = tail->thePoint.X; segY1 = tail->thePoint.Y;

		while (currVertex != nullptr) {
			// set second vertix of segment
			segX2 = currVertex->thePoint.X; segY2 = currVertex->thePoint.Y;

			// check if segment is of interest
			tooHigh = min(segY1, segY2) > testY;
			tooLow = max(segY1, segY2) < testY;
			tooLeft = max(segX1, segX2) < testX;
			if (!tooHigh && !tooLow && !tooLeft) { // segment is of interest

				// check for horz segment (avoid divide by zero error in crossX calc)
				if (fabs(segY1 - segY2) < TOLERANCE) {
					if (min(segX1, segX2) <= testX) // test point on edge
						return isInclusive;

					// else segment can be ignored
				}
				else { // process segment

					// calculate crossX
					crossX = segX1 + (segX2 - segX1) * (testY - segY1) / (segY2 - segY1);

					// check if point on edge
					if (fabs(crossX - testX) < TOLERANCE)
						return isInclusive;     // << possible exit from function

					else if (crossX > testX) { // be sure crossX is to right of testX
						// check if crossX on vertex and other point is above
						if ((fabs(testY - segY1) < TOLERANCE && segY2 > testY)
							|| (fabs(testY - segY2) < TOLERANCE && segY1 > testY)
							|| (fabs(testY - segY1) > TOLERANCE && fabs(testY - segY2) > TOLERANCE))
							crossCount++;
					}
				}
			}

			// set first vertix of segment
			segX1 = segX2; segY1 = segY2;
			currVertex = currVertex->next;
		}

		return(crossCount % 2 == 1);
	}

}

void Shape2D::paint(System::Drawing::Graphics ^ g, System::Drawing::Color c,
	bool filled, bool showPoints)
{
	using namespace System::Drawing;
	cli::array<Point> ^ pointArray = gcnew cli::array<Point>(vertexCount);
	Pen^ cirPen = gcnew Pen(Color::ForestGreen, 10.0f);
	Pen^ filPen = gcnew Pen(c, 10.0f);
	Brush^ filBrush = gcnew SolidBrush(c);

	if (head != nullptr) {
		ShapeVertex *currVertex, *prevVertex;
		float adj = 1000.;
		g->ScaleTransform(1. / adj, 1. / adj);
		prevVertex = tail;
		currVertex = head;
		int i = 0;
		while (currVertex != nullptr) {
			pointArray[i++] = Point(currVertex->thePoint.X * adj, currVertex->thePoint.Y*adj);
			prevVertex = currVertex;
			currVertex = currVertex->next;
		}
		float d = getMinRadius() * 3;
		g->DrawEllipse(cirPen, -d / 2, -d / 2, d, d);
		g->DrawPolygon(filPen, pointArray);
		if (filled)
			g->FillPolygon(filBrush, pointArray);
		g->ScaleTransform(adj, adj);
	}
	/*using namespace System::Drawing;
	if (head != nullptr) {
		ShapeVertex *currVertex, *prevVertex;
		float adj = 1000.;
		Pen^ thePen = gcnew Pen(c, maxRadius / 50.*adj);
		Pen^ pointPen = gcnew Pen(Color::Green, 0.0);
		float pointDiam = maxRadius / 25.*adj;

		g->ScaleTransform(1. / adj, 1. / adj);
		prevVertex = tail;
		currVertex = head;
		while (currVertex != nullptr) {
			// draw segment
			g->DrawLine(thePen, (float)prevVertex->thePoint.X*adj, (float)prevVertex->thePoint.Y*adj,
				(float)currVertex->thePoint.X*adj, (float)currVertex->thePoint.Y*adj);

			if (showPoints)
				g->DrawEllipse(pointPen, currVertex->thePoint.X*adj - pointDiam / 2.f,
					currVertex->thePoint.Y*adj - pointDiam / 2.f, pointDiam, pointDiam);

			prevVertex = currVertex;
			currVertex = currVertex->next;
		}
		g->ScaleTransform(adj, adj);
	}*/
}

Point2D Shape2D::getIntersection(double theta)
{
	if (head != nullptr) {
		// adjust theta
		while (theta < 0)
			theta += 360;
		theta = fmod(theta, 360.);

		Point2D *intersect;
		Point2D origin = { 0., 0. };
		Point2D vectorEnd = { maxRadius * cos(theta * atan(1.) / 45.) ,
							maxRadius * sin(theta * atan(1.) / 45.) };
		ShapeVertex *prevVertex = tail;
		ShapeVertex *currVertex = head;
		bool continueLoop = true;

		while (currVertex != nullptr && continueLoop) {
			intersect = Line2D::getIntersection(origin, vectorEnd,
				prevVertex->thePoint, currVertex->thePoint);
			if (intersect != nullptr && Line2D::isbetween(prevVertex->thePoint, currVertex->thePoint, *intersect)) {

				double orientation = Line2D::getDirection(origin, *intersect);
				if (fabs(orientation - theta) < TOLERANCE)
					return *intersect;  //  <<< possible exit from function
			}
			prevVertex = currVertex;
			currVertex = currVertex->next;
		}
	}

	Point2D intersect = { 0.,0. };
	return intersect;

}
void Shape2D::resetMinMax()
{
	if (head != nullptr) {
		ShapeVertex *currVertex = head;

		minX = maxX = head->thePoint.X;
		minY = maxY = head->thePoint.Y;
		maxRadius = minRadius = -1.;

		while (currVertex != nullptr) {
			updateMinMax(currVertex->thePoint.X, currVertex->thePoint.Y);
			currVertex = currVertex->next;
		}
	}
}

void Shape2D::updateMinMax(double currX, double currY)
{
	// using if
	if (currX < minX) minX = currX;
	if (currX > maxX) maxX = currX;
	if (currY < minY) minY = currY;
	if (currY > maxY) maxY = currY;

	// alternate method (using min() and max() functions
	// need to #include <algorithm> 
	//minX = min(minX, currX);
	//maxX = max(maxX, currX);
	//minY = min(minY, currY);
	//maxY = max(maxY, currY);

	// alternate method (using the ternary operator ?)
	//minX = (currX < minX) ? currX : minX;
	//maxX = (currX > maxX) ? currX : maxX;
	//minY = (currY < minY) ? currY : minY;
	//maxY = (currY > maxY) ? currY : maxY;

	double currRadius = Line2D::getLength(0., 0., currX, currY);
	if (maxRadius == -1. || maxRadius < currRadius)
		maxRadius = currRadius;
	if (minRadius == -1. || minRadius > currRadius)
		minRadius = currRadius;
}

void Shape2D::deleteAndReset()
{
	ShapeVertex *prevVertex;
	while (head != nullptr) {
		prevVertex = head;
		head = head->next;
		delete prevVertex;
	}
	head = tail = nullptr;
	vertexCount = 0;
	maxRadius = maxRadius = -1.;

}

void  Shape2D::writeFile(ostream &output) const
{
	ShapeVertex *currVertex = head;
	output << "Shape:" << endl;
	int counter = 1;
	while (currVertex != nullptr) {
		// for output that matches the input exactly
		output << currVertex->thePoint.X << "\t" << currVertex->thePoint.Y << endl;

		// for nicely numbered and formated output
		//output << counter << ". " << currVertex->thePoint.X
		//	<< ", " << currVertex->thePoint.Y << endl;

		currVertex = currVertex->next;
		counter++;
	}
	output << "End Shape:" << endl;
}

ostream & operator<<(ostream & os, const Shape2D & aShape)
{
	aShape.writeFile(os);
	return os;
}
