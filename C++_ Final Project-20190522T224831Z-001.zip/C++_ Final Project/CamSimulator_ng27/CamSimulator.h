/*
Nestor Gomez
24-280A C++ for Engineers
PS 07, Due: 4/9/19

*/

#pragma once
#include <chrono>
#include <ctime>
#include "Cam.h"
#include "CamEditor.h"
#include "MotionViewer.h"
#include "Follower.h"
#include "FlickerLessPanel.h"
#include "StringPlus.h"  // moved marshal stuff to StringPlus
#include <chrono>

using namespace System;
using namespace System::Threading;

// using flickerless panel makes the form design view not work.
// to use flickerless panel or allow the design view, use one of these
// in InitComponents() function
//    for design view >>>>    this->mainPanel = (gcnew System::Windows::Forms::Panel());
//    for flickerless >>>>    this->mainPanel = (gcnew FlickerLessPanel());
typedef enum angleUnits {
	DEGREES, RADIANS, RPM
};

typedef std::chrono::high_resolution_clock Clock;


namespace CamSimulatorng27 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for CamSimulator
	/// </summary>
	public ref class CamSimulator : public System::Windows::Forms::Form
	{
	public:
		angleUnits mode;
		CamSimulator(void)
		{
			mouseInPanel = false;

			panX = panY = 300;
			zoomLevel = 1.;

			showTheGrid = false;
			animationRunning = false;

			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			mouseInPanel = false;

			panX = panY = 300;
			zoomLevel = 1.;
			showTheGrid = false;
			animationRunning = false;
			followerHandle->Left = -100;

		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~CamSimulator()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected:
		Cam *theCam;
		Follower *theFollower;
		Shape2D *theShape;
		double zoomLevel = 1.0;
		int panX, panY, currX, currY;
		bool saveStateCam, saveStateFol, loadStateCam, loadStateFol, loadStateCam2;
		bool showTheGrid, mouseInPanel, animationRunning;
		CamSimulatorng27::MotionViewer ^theViewer;
		Color camColor = Color::DodgerBlue;
		bool filled = false;

	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  userFeedbackLabel;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label6;


	private: System::Windows::Forms::Panel^  mainPanel;
	private: System::Windows::Forms::TextBox^  startXbox;
	private: System::Windows::Forms::TextBox^  startYbox;


	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::TextBox^  endXbox;
	private: System::Windows::Forms::TextBox^  endYbox;


	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::TextBox^  followerIDbox;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::TextBox^  simIntervalBox;


	private: System::Windows::Forms::Button^  changeCamButton;

	private: System::Windows::Forms::Label^  label11;

	private: System::Windows::Forms::Button^  animateButton;
	private: System::Windows::Forms::Button^  simulateButton;

	private: System::Windows::Forms::Label^  coordLabel;
	public: System::Windows::Forms::Label^  camIDlabel;
	private: System::Windows::Forms::Button^  loadButton;
	public:
	private: System::Windows::Forms::Button^  saveButton;
	private: System::Windows::Forms::HScrollBar^  currAngleScroll;
	private: System::Windows::Forms::Button^  resetViewButton;
	private: System::Windows::Forms::Button^  viewMotionButton;
	private: System::Windows::Forms::TextBox^  camSpeedBox;
	private: System::Windows::Forms::Label^  label12;
	private: System::Windows::Forms::Label^  followerHandle;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::ComboBox^  comboBox2;
	private: System::Windows::Forms::Label^  label13;
	private: System::Windows::Forms::Label^  label14;
	private: System::Windows::Forms::ComboBox^  comboBox3;
	private: System::Windows::Forms::ErrorProvider^  errorProvider1;
	private: System::ComponentModel::IContainer^  components;
	private:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->userFeedbackLabel = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->mainPanel = (gcnew System::Windows::Forms::Panel());
			this->followerHandle = (gcnew System::Windows::Forms::Label());
			this->coordLabel = (gcnew System::Windows::Forms::Label());
			this->currAngleScroll = (gcnew System::Windows::Forms::HScrollBar());
			this->startXbox = (gcnew System::Windows::Forms::TextBox());
			this->startYbox = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->endXbox = (gcnew System::Windows::Forms::TextBox());
			this->endYbox = (gcnew System::Windows::Forms::TextBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->followerIDbox = (gcnew System::Windows::Forms::TextBox());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->simIntervalBox = (gcnew System::Windows::Forms::TextBox());
			this->changeCamButton = (gcnew System::Windows::Forms::Button());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->animateButton = (gcnew System::Windows::Forms::Button());
			this->simulateButton = (gcnew System::Windows::Forms::Button());
			this->camIDlabel = (gcnew System::Windows::Forms::Label());
			this->loadButton = (gcnew System::Windows::Forms::Button());
			this->saveButton = (gcnew System::Windows::Forms::Button());
			this->resetViewButton = (gcnew System::Windows::Forms::Button());
			this->viewMotionButton = (gcnew System::Windows::Forms::Button());
			this->camSpeedBox = (gcnew System::Windows::Forms::TextBox());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->errorProvider1 = (gcnew System::Windows::Forms::ErrorProvider(this->components));
			this->mainPanel->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->errorProvider1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(9, 132);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(56, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Start Point";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label2->Location = System::Drawing::Point(4, 4);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(233, 24);
			this->label2->TabIndex = 0;
			this->label2->Text = L"Cam-Follower Simulator";
			// 
			// userFeedbackLabel
			// 
			this->userFeedbackLabel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->userFeedbackLabel->AutoSize = true;
			this->userFeedbackLabel->Location = System::Drawing::Point(149, 604);
			this->userFeedbackLabel->Name = L"userFeedbackLabel";
			this->userFeedbackLabel->Size = System::Drawing::Size(116, 13);
			this->userFeedbackLabel->TabIndex = 0;
			this->userFeedbackLabel->Text = L"Ready to model system";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(9, 183);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(53, 13);
			this->label4->TabIndex = 0;
			this->label4->Text = L"End Point";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(9, 154);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(17, 13);
			this->label5->TabIndex = 0;
			this->label5->Text = L"X:";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(75, 154);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(17, 13);
			this->label6->TabIndex = 0;
			this->label6->Text = L"Y:";
			// 
			// mainPanel
			// 
			this->mainPanel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->mainPanel->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(192)));
			this->mainPanel->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->mainPanel->Controls->Add(this->followerHandle);
			this->mainPanel->Controls->Add(this->coordLabel);
			this->mainPanel->Controls->Add(this->currAngleScroll);
			this->mainPanel->Location = System::Drawing::Point(152, 31);
			this->mainPanel->Name = L"mainPanel";
			this->mainPanel->Size = System::Drawing::Size(645, 570);
			this->mainPanel->TabIndex = 1;
			this->mainPanel->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &CamSimulator::mainPanel_Paint);
			this->mainPanel->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &CamSimulator::mainPanel_MouseDown);
			this->mainPanel->MouseEnter += gcnew System::EventHandler(this, &CamSimulator::mainPanel_MouseEnter);
			this->mainPanel->MouseLeave += gcnew System::EventHandler(this, &CamSimulator::mainPanel_MouseLeave);
			this->mainPanel->MouseMove += gcnew System::Windows::Forms::MouseEventHandler(this, &CamSimulator::mainPanel_MouseMove);
			this->mainPanel->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &CamSimulator::mainPanel_MouseUp);
			// 
			// followerHandle
			// 
			this->followerHandle->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->followerHandle->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(0)));
			this->followerHandle->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->followerHandle->Location = System::Drawing::Point(286, 254);
			this->followerHandle->Name = L"followerHandle";
			this->followerHandle->Size = System::Drawing::Size(15, 15);
			this->followerHandle->TabIndex = 1;
			this->followerHandle->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &CamSimulator::followerHandle_MouseDown);
			this->followerHandle->MouseMove += gcnew System::Windows::Forms::MouseEventHandler(this, &CamSimulator::followerHandle_MouseMove);
			// 
			// coordLabel
			// 
			this->coordLabel->AutoSize = true;
			this->coordLabel->Location = System::Drawing::Point(-200, 29);
			this->coordLabel->Name = L"coordLabel";
			this->coordLabel->Size = System::Drawing::Size(42, 13);
			this->coordLabel->TabIndex = 0;
			this->coordLabel->Text = L"nothing";
			// 
			// currAngleScroll
			// 
			this->currAngleScroll->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->currAngleScroll->Location = System::Drawing::Point(-2, 552);
			this->currAngleScroll->Maximum = 360;
			this->currAngleScroll->Name = L"currAngleScroll";
			this->currAngleScroll->Size = System::Drawing::Size(643, 14);
			this->currAngleScroll->TabIndex = 5;
			this->currAngleScroll->Value = 360;
			this->currAngleScroll->ValueChanged += gcnew System::EventHandler(this, &CamSimulator::currAngleScroll_ValueChanged);
			// 
			// startXbox
			// 
			this->startXbox->Location = System::Drawing::Point(29, 151);
			this->startXbox->Name = L"startXbox";
			this->startXbox->Size = System::Drawing::Size(40, 20);
			this->startXbox->TabIndex = 2;
			this->startXbox->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &CamSimulator::startbox_KeyDown);
			this->startXbox->Leave += gcnew System::EventHandler(this, &CamSimulator::startbox_Leave);
			// 
			// startYbox
			// 
			this->startYbox->Location = System::Drawing::Point(93, 152);
			this->startYbox->Name = L"startYbox";
			this->startYbox->Size = System::Drawing::Size(40, 20);
			this->startYbox->TabIndex = 2;
			this->startYbox->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &CamSimulator::startbox_KeyDown);
			this->startYbox->Leave += gcnew System::EventHandler(this, &CamSimulator::startbox_Leave);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(9, 205);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(17, 13);
			this->label3->TabIndex = 0;
			this->label3->Text = L"X:";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(75, 205);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(17, 13);
			this->label7->TabIndex = 0;
			this->label7->Text = L"Y:";
			// 
			// endXbox
			// 
			this->endXbox->Location = System::Drawing::Point(29, 202);
			this->endXbox->Name = L"endXbox";
			this->endXbox->Size = System::Drawing::Size(40, 20);
			this->endXbox->TabIndex = 2;
			this->endXbox->Enter += gcnew System::EventHandler(this, &CamSimulator::endbox_Leave);
			this->endXbox->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &CamSimulator::endbox_KeyDown);
			// 
			// endYbox
			// 
			this->endYbox->Location = System::Drawing::Point(93, 203);
			this->endYbox->Name = L"endYbox";
			this->endYbox->Size = System::Drawing::Size(40, 20);
			this->endYbox->TabIndex = 2;
			this->endYbox->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &CamSimulator::endbox_KeyDown);
			this->endYbox->Leave += gcnew System::EventHandler(this, &CamSimulator::endbox_Leave);
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(9, 93);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(60, 13);
			this->label8->TabIndex = 0;
			this->label8->Text = L"Follower ID";
			// 
			// followerIDbox
			// 
			this->followerIDbox->Location = System::Drawing::Point(12, 109);
			this->followerIDbox->Name = L"followerIDbox";
			this->followerIDbox->Size = System::Drawing::Size(121, 20);
			this->followerIDbox->TabIndex = 2;
			this->followerIDbox->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &CamSimulator::followerIDbox_KeyDown);
			this->followerIDbox->Leave += gcnew System::EventHandler(this, &CamSimulator::followerIDbox_Leave);
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(11, 239);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(93, 13);
			this->label9->TabIndex = 0;
			this->label9->Text = L"Simulation Interval";
			// 
			// simIntervalBox
			// 
			this->simIntervalBox->Location = System::Drawing::Point(14, 255);
			this->simIntervalBox->Name = L"simIntervalBox";
			this->simIntervalBox->Size = System::Drawing::Size(25, 20);
			this->simIntervalBox->TabIndex = 2;
			this->simIntervalBox->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &CamSimulator::intervalbox_KeyDown);
			this->simIntervalBox->Leave += gcnew System::EventHandler(this, &CamSimulator::intervalbox_Leave);
			// 
			// changeCamButton
			// 
			this->changeCamButton->Location = System::Drawing::Point(64, 303);
			this->changeCamButton->Name = L"changeCamButton";
			this->changeCamButton->Size = System::Drawing::Size(69, 21);
			this->changeCamButton->TabIndex = 1;
			this->changeCamButton->Text = L"Add";
			this->changeCamButton->UseVisualStyleBackColor = true;
			this->changeCamButton->Click += gcnew System::EventHandler(this, &CamSimulator::changeCamButton_Click);
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(11, 307);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(28, 13);
			this->label11->TabIndex = 0;
			this->label11->Text = L"Cam";
			// 
			// animateButton
			// 
			this->animateButton->Location = System::Drawing::Point(12, 516);
			this->animateButton->Name = L"animateButton";
			this->animateButton->Size = System::Drawing::Size(126, 49);
			this->animateButton->TabIndex = 3;
			this->animateButton->Text = L"Start Animation";
			this->animateButton->UseVisualStyleBackColor = true;
			this->animateButton->Click += gcnew System::EventHandler(this, &CamSimulator::animateButton_Click);
			// 
			// simulateButton
			// 
			this->simulateButton->Location = System::Drawing::Point(12, 418);
			this->simulateButton->Name = L"simulateButton";
			this->simulateButton->Size = System::Drawing::Size(126, 21);
			this->simulateButton->TabIndex = 3;
			this->simulateButton->Text = L"Simulate";
			this->simulateButton->UseVisualStyleBackColor = true;
			this->simulateButton->Click += gcnew System::EventHandler(this, &CamSimulator::simulateButton_Click);
			// 
			// camIDlabel
			// 
			this->camIDlabel->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->camIDlabel->Location = System::Drawing::Point(14, 327);
			this->camIDlabel->Name = L"camIDlabel";
			this->camIDlabel->Size = System::Drawing::Size(119, 20);
			this->camIDlabel->TabIndex = 0;
			this->camIDlabel->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// loadButton
			// 
			this->loadButton->Location = System::Drawing::Point(12, 34);
			this->loadButton->Name = L"loadButton";
			this->loadButton->Size = System::Drawing::Size(126, 21);
			this->loadButton->TabIndex = 3;
			this->loadButton->Text = L"Load File";
			this->loadButton->UseVisualStyleBackColor = true;
			this->loadButton->Click += gcnew System::EventHandler(this, &CamSimulator::loadButton_Click);
			// 
			// saveButton
			// 
			this->saveButton->Location = System::Drawing::Point(12, 61);
			this->saveButton->Name = L"saveButton";
			this->saveButton->Size = System::Drawing::Size(126, 21);
			this->saveButton->TabIndex = 3;
			this->saveButton->Text = L"Save File";
			this->saveButton->UseVisualStyleBackColor = true;
			this->saveButton->Click += gcnew System::EventHandler(this, &CamSimulator::saveButton_Click);
			// 
			// resetViewButton
			// 
			this->resetViewButton->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->resetViewButton->Location = System::Drawing::Point(723, 605);
			this->resetViewButton->Name = L"resetViewButton";
			this->resetViewButton->Size = System::Drawing::Size(72, 19);
			this->resetViewButton->TabIndex = 6;
			this->resetViewButton->Text = L"Reset View";
			this->resetViewButton->UseVisualStyleBackColor = true;
			this->resetViewButton->Click += gcnew System::EventHandler(this, &CamSimulator::resetViewButton_Click);
			// 
			// viewMotionButton
			// 
			this->viewMotionButton->Location = System::Drawing::Point(12, 445);
			this->viewMotionButton->Name = L"viewMotionButton";
			this->viewMotionButton->Size = System::Drawing::Size(126, 21);
			this->viewMotionButton->TabIndex = 7;
			this->viewMotionButton->Text = L"View Motion";
			this->viewMotionButton->UseVisualStyleBackColor = true;
			this->viewMotionButton->Click += gcnew System::EventHandler(this, &CamSimulator::viewMotionButton_Click);
			// 
			// camSpeedBox
			// 
			this->camSpeedBox->Location = System::Drawing::Point(12, 367);
			this->camSpeedBox->Name = L"camSpeedBox";
			this->camSpeedBox->Size = System::Drawing::Size(121, 20);
			this->camSpeedBox->TabIndex = 2;
			this->camSpeedBox->Text = L"5.0";
			this->camSpeedBox->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &CamSimulator::camSpeedbox_KeyDown);
			this->camSpeedBox->Leave += gcnew System::EventHandler(this, &CamSimulator::camSpeedbox_Leave);
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Location = System::Drawing::Point(11, 351);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(86, 13);
			this->label12->TabIndex = 0;
			this->label12->Text = L"Cam speed (rpm)";
			// 
			// comboBox1
			// 
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(4) {
				L"Load Cam (with Editor)", L"Load Cam (no Editor)",
					L"Load Follower", L"Load All"
			});
			this->comboBox1->Location = System::Drawing::Point(370, 8);
			this->comboBox1->Margin = System::Windows::Forms::Padding(2);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(132, 21);
			this->comboBox1->TabIndex = 8;
			this->comboBox1->SelectedIndexChanged += gcnew System::EventHandler(this, &CamSimulator::comboBox1_SelectedIndexChanged);
			// 
			// comboBox2
			// 
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(3) { L"Save Cam", L"Save Follower", L"Save Both" });
			this->comboBox2->Location = System::Drawing::Point(657, 8);
			this->comboBox2->Margin = System::Windows::Forms::Padding(2);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(116, 21);
			this->comboBox2->TabIndex = 9;
			this->comboBox2->SelectedIndexChanged += gcnew System::EventHandler(this, &CamSimulator::comboBox2_SelectedIndexChanged);
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label13->Location = System::Drawing::Point(242, 10);
			this->label13->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(129, 15);
			this->label13->TabIndex = 10;
			this->label13->Text = L"Choose Load Type:";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label14->Location = System::Drawing::Point(513, 10);
			this->label14->Margin = System::Windows::Forms::Padding(2, 0, 2, 0);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(128, 15);
			this->label14->TabIndex = 11;
			this->label14->Text = L"Choose Save Type:";
			// 
			// comboBox3
			// 
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Items->AddRange(gcnew cli::array< System::Object^  >(3) { L"degrees", L"radians", L"rpm" });
			this->comboBox3->Location = System::Drawing::Point(45, 255);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(88, 21);
			this->comboBox3->TabIndex = 12;
			this->comboBox3->Text = L"(Select Units)";
			this->comboBox3->SelectedIndexChanged += gcnew System::EventHandler(this, &CamSimulator::comboBox3_SelectedIndexChanged);
			// 
			// errorProvider1
			// 
			this->errorProvider1->ContainerControl = this;
			// 
			// CamSimulator
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(192)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->ClientSize = System::Drawing::Size(805, 632);
			this->Controls->Add(this->comboBox3);
			this->Controls->Add(this->label14);
			this->Controls->Add(this->label13);
			this->Controls->Add(this->comboBox2);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->viewMotionButton);
			this->Controls->Add(this->resetViewButton);
			this->Controls->Add(this->saveButton);
			this->Controls->Add(this->loadButton);
			this->Controls->Add(this->animateButton);
			this->Controls->Add(this->simulateButton);
			this->Controls->Add(this->changeCamButton);
			this->Controls->Add(this->endYbox);
			this->Controls->Add(this->startYbox);
			this->Controls->Add(this->endXbox);
			this->Controls->Add(this->simIntervalBox);
			this->Controls->Add(this->camSpeedBox);
			this->Controls->Add(this->followerIDbox);
			this->Controls->Add(this->startXbox);
			this->Controls->Add(this->mainPanel);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->userFeedbackLabel);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->camIDlabel);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label12);
			this->Controls->Add(this->label11);
			this->Controls->Add(this->label9);
			this->Controls->Add(this->label8);
			this->Controls->Add(this->label1);
			this->Name = L"CamSimulator";
			this->Text = L"CamSimulator";
			this->MouseWheel += gcnew System::Windows::Forms::MouseEventHandler(this, &CamSimulator::CamSimulator_MouseWheel);
			this->Resize += gcnew System::EventHandler(this, &CamSimulator::CamSimulator_Resize);
			this->mainPanel->ResumeLayout(false);
			this->mainPanel->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->errorProvider1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	public: void refreshView() {
		mainPanel->Refresh();
	}
	private: System::Void changeCamButton_Click(System::Object^  sender, System::EventArgs^  e) {
		if (theCam == nullptr) {
			theCam = new Cam;
			changeCamButton->Text = "Edit";
		}
		CamEditorng27::CamEditor theCamEditor;
		theCamEditor.setCam(theCam);
		//theCamEditor.setSimulator(this);

		theCamEditor.ShowDialog();
		//		mainPanel->Refresh();
		camIDlabel->Text = gcnew String(theCam->getID().c_str());
		checkMaterial();
		mainPanel->Refresh();
		userFeedbackLabel->Text = "Cam: " + gcnew String(theCam->getID().c_str())
			+ " now in use.";
		if (theFollower == nullptr) {
			theFollower = new Follower;
			storeSimParameters();
		}
		theFollower->setCam(theCam);

		resetViewButton_Click(nullptr, nullptr);
	}

	private: System::Void mainPanel_Paint(System::Object^  sender, System::Windows::Forms::PaintEventArgs^  e) {
		e->Graphics->TranslateTransform(panX, panY);
		e->Graphics->ScaleTransform(zoomLevel, -zoomLevel);

		if (theShape != nullptr) {
			theShape->paint(e->Graphics, camColor, filled);
		}

		if (theCam != nullptr) {
			theCam->paint(e->Graphics,camColor, filled);
		}
		if (theFollower != nullptr) {
			setHandlerCoords();
			theFollower->paint(e->Graphics);
		}
	}

	private: void displaySimParameters() {
		if (theCam != nullptr) {
			camIDlabel->Text = gcnew String(theCam->getID().c_str());
		}
		if (theFollower != nullptr) {
			followerIDbox->Text = gcnew String(theFollower->getID().c_str());
			startXbox->Text = theFollower->getStartPoint().X.ToString("0.###");
			startYbox->Text = theFollower->getStartPoint().Y.ToString("0.###");
			endXbox->Text = theFollower->getEndPoint().X.ToString("0.###");
			endYbox->Text = theFollower->getEndPoint().Y.ToString("0.###");
			simIntervalBox->Text = theFollower->getSimInterval().ToString("0.###");

			setHandlerCoords();

		}
	}


	private: void followerIDbox_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
		if (e->KeyCode == Keys::Enter) {
			auto temp = followerIDbox->Text;
			getfollowerIDFromBox();
		}
	}
	private: System::Void followerIDbox_Leave(System::Object^  sender, System::EventArgs^  e) {
		getfollowerIDFromBox();
	}
	private: void getfollowerIDFromBox() {
		if (theFollower == nullptr)
			theFollower = new Follower();
		string temp = StringPlus::convertString(followerIDbox->Text);
		theFollower->setID(StringPlus::trim(temp));
	}

	private: void startbox_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
		if (e->KeyCode == Keys::Enter) {
			getStartPointFromBox();
		}
	}
	private: System::Void startbox_Leave(System::Object^  sender, System::EventArgs^  e) {
		getStartPointFromBox();
	}
	private: void getStartPointFromBox() {

		try {
			double currX, currY;
			if (startXbox->Text == "")
				currX = 0.;
			else
				currX = Convert::ToDouble(startXbox->Text);
			if (startYbox->Text == "")
				currY = 0.;
			else
				currY = Convert::ToDouble(startYbox->Text);

			if (theFollower == nullptr)
				theFollower = new Follower();
			theFollower->setStartPoint({ currX, currY });
			mainPanel->Refresh();
		}
		catch (Exception ^excep) {
			MessageBox::Show(this, "Values -> " + startXbox->Text + ", " + startYbox->Text
				+ " <- in Start Point input could not be converted to decimal.\n"
				+ excep->Message, "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}

	private: void endbox_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
		if (e->KeyCode == Keys::Enter) {
			getEndPointFromBox();
		}
	}
	private: System::Void endbox_Leave(System::Object^  sender, System::EventArgs^  e) {
		getEndPointFromBox();
	}
	private: void getEndPointFromBox() {

		try {
			double currX, currY;
			if (endXbox->Text == "")
				currX = 0.;
			else
				currX = Convert::ToDouble(endXbox->Text);
			if (endYbox->Text == "")
				currY = 0.;
			else
				currY = Convert::ToDouble(endYbox->Text);

			if (theFollower == nullptr)
				theFollower = new Follower();
			theFollower->setEndPoint({ currX, currY });
			mainPanel->Refresh();
		}
		catch (Exception ^excep) {
			MessageBox::Show(this, "Values -> " + endXbox->Text + ", " + endYbox->Text
				+ " <- in End Point input could not be converted to decimal.\n"
				+ excep->Message, "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}

	private: void intervalbox_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
		if (e->KeyCode == Keys::Enter) {
			getIntervalFromBox();
		}
	}
	private: System::Void intervalbox_Leave(System::Object^  sender, System::EventArgs^  e) {
		getIntervalFromBox();
	}
	private: void getIntervalFromBox() {

		try {
			double simInterval;
			if (simIntervalBox->Text == "")
				simInterval = 10.;
			else
				simInterval = Convert::ToDouble(simIntervalBox->Text);

			if (theFollower == nullptr)
				theFollower = new Follower();
			theFollower->setSimInterval(simInterval);
			simIntervalBox->Text = simInterval.ToString();

		}
		catch (Exception ^excep) {
			MessageBox::Show(this, "Value -> " + simIntervalBox->Text
				+ " <- in Simulation Interval input could not be converted to decimal.\n"
				+ excep->Message, "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}

	private: void camSpeedbox_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
		if (e->KeyCode == Keys::Enter) {
			getCamSpeedFromBox();
		}
	}
	private: System::Void camSpeedbox_Leave(System::Object^  sender, System::EventArgs^  e) {
		getCamSpeedFromBox();
	}
	private: void getCamSpeedFromBox() {

		try {
			double camSpeed;
			if (camSpeedBox->Text == "")
				camSpeed = 5.;
			else
				camSpeed = Convert::ToDouble(camSpeedBox->Text);

			if (theCam != nullptr) {
				theCam->setCamSpeed(camSpeed);
				camSpeedBox->Text = camSpeed.ToString();
			}

		}
		catch (Exception ^excep) {
			MessageBox::Show(this, "Value -> " + camSpeedBox->Text
				+ " <- in Cam Speed input could not be converted to decimal.\n"
				+ excep->Message, "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}

	private: void storeSimParameters() {
		getfollowerIDFromBox();
		getStartPointFromBox();
		getEndPointFromBox();
		getIntervalFromBox();
	}

	private: System::Void CamSimulator_Resize(System::Object^  sender, System::EventArgs^  e) {
		mainPanel->Refresh();
	}

	private: void CamSimulator_MouseWheel(Object^ sender, System::Windows::Forms::MouseEventArgs^ e)
	{
		// panel does not take a mousewheel event, so we must handle it at the the level of the form
		// but only if the mouse pointer is inside the panel
		if (mouseInPanel) {

			float zoomStep = 1.2f;  // change as needed for more effect per wheel roll
			float oldZoom = zoomLevel; // will need for resetting panX and panY

			// get actual location of pointer inside the panel (as opposed to the form itself)
			int adjustedX = e->X - mainPanel->Location.X - mainPanel->Margin.Left;
			int adjustedY = e->Y - mainPanel->Location.Y - mainPanel->Margin.Top;

			//e->Delta * SystemInformation::MouseWheelScrollLines / 120
			if (e->Delta < 0) // zoom out
				zoomLevel = zoomLevel / zoomStep;
			else
				zoomLevel = zoomLevel * zoomStep;

			// reset panX and panY such that the coords under the mouse pointer are unchanged
			// i.e., we can zoom in/out on a specific point
			panX = (int)round((adjustedX * (oldZoom - zoomLevel)
				+ panX * zoomLevel) / oldZoom);
			panY = (int)round((adjustedY * (oldZoom - zoomLevel)
				+ panY * zoomLevel) / oldZoom);

			mainPanel->Refresh();

		}
	}

	private: System::Void mainPanel_MouseEnter(System::Object^  sender, System::EventArgs^  e) {
		// only needed because the panel doesn't take a mousewheel event, so we must use
		// the main form instead to detect the use of mousewheel
		mouseInPanel = true;
	}

	private: System::Void mainPanel_MouseLeave(System::Object^  sender, System::EventArgs^  e) {
		// only needed because the panel doesn't take a mousewheel event, so we must use
		// the main form instead to detect the use of mousewheel
		mouseInPanel = false;
	}

	private: System::Void mainPanel_MouseMove(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		// this function allows panning by pressing down on mousewheel and dragging
		// essentially, we adjust panning by however much the mouse is moved
		if (e->Button == System::Windows::Forms::MouseButtons::Middle) {
			panX += (e->X - currX);
			panY += (e->Y - currY);
			mainPanel->Refresh();
			currX = e->X; currY = e->Y; // need to constantly update to allow drag
		}
		if (e->Button == System::Windows::Forms::MouseButtons::Left) {
			int temp = temp;
		}

	}

	private: System::Void mainPanel_MouseDown(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		// this function is also part of panning (sets the initial mousewheel click position)
		if (e->Button == System::Windows::Forms::MouseButtons::Middle) {
			currX = e->X;
			currY = e->Y;
		}
		else if (e->Button == System::Windows::Forms::MouseButtons::Left) {
			float scaledX = (e->X - panX) / zoomLevel;
			float scaledY = (e->Y - panY) / -zoomLevel;
			coordLabel->Text = scaledX.ToString("0.###") + "," + scaledY.ToString("0.###");

			int adjustedX = e->X - 5 - coordLabel->Width;
			int adjustedY = e->Y - 5 - coordLabel->Height;

			coordLabel->Left = adjustedX; coordLabel->Top = adjustedY;

		}

	}

	private: System::Void mainPanel_MouseUp(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		coordLabel->Left = -150;
	}

	private: System::Void animateButton_Click(System::Object^  sender, System::EventArgs^  e) {
		/*animationRunning = !animationRunning;
		if (animationRunning) {
			animateButton->Text = "Stop Animation";
			getCamSpeedFromBox();

			// setting the following to false risks cross-thread issues, but theses
			// risks are not very applicable
			System::Windows::Forms::Form::CheckForIllegalCrossThreadCalls = false;

			// start the thread that will run the animation
			System::Threading::Thread ^animationThread = gcnew System::Threading::Thread(
				gcnew System::Threading::ThreadStart(this, &CamSimulator::animateContinuous));
			animationThread->Start();
		}
		else
			animateButton->Text = "Start Animation";*/

		if (theFollower != nullptr)
			theFollower->generateMotion();
		int maxAngle = 360; double interval = System::Convert::ToDouble(simIntervalBox->Text);
		int sleepTime = 50;
		if (mode == RADIANS) {
			interval = interval * 180 / 3.1415;
		}
		else if (mode == RPM) {
			double revspm = Convert::ToDouble(simIntervalBox->Text);
			interval = 360 * revspm / CLOCKS_PER_SEC;
		}
		for (int i = 0; i < maxAngle;) {
			theCam->step(theFollower, interval);
			mainPanel->Refresh();
			i = i + interval;
			Thread^ current = Thread::CurrentThread;
			Thread::Sleep(sleepTime);
		}
	}

	private: System::Void resetViewButton_Click(System::Object^  sender, System::EventArgs^  e) {
		panX = mainPanel->Width / 2;
		panY = mainPanel->Height / 2;
		if (theCam == nullptr) { // use some defaults
			zoomLevel = 2.0;
			//circleSpacing = 4.;
		}
		else {
			double referenceSize = min(mainPanel->Width, mainPanel->Height);
			double camSize = theCam->getLargestRadius() * 2.;
			zoomLevel = referenceSize / camSize * 0.7;
			//circleSpacing = max(int(camSize / 8), 1) / 2.;
		}
		//gridCheckBox->Text = "Grid (" + circleSpacing.ToString("0.##") + ")";
		mainPanel->Refresh();
		if (theViewer != nullptr)
			theViewer->Refresh();

		followerHandle->Left = 286;  followerHandle->Top = 254;

	}

	private: System::Void currAngleScroll_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
		if (theCam != nullptr) {
			//std::chrono::duration<double> elapsed_milliseconds;
			//auto start = std::chrono::system_clock::now();

			theCam->setCurrAngle(theCam->getStartAngle() + currAngleScroll->Value);
			mainPanel->Refresh();

			//elapsed_milliseconds = std::chrono::system_clock::now() - start;
			//double refreshTime = elapsed_milliseconds.count();
			//refreshTime = refreshTime;
		}
	}

	private: System::Void loadButton_Click(System::Object^  sender, System::EventArgs^  e) {
		if (!loadStateFol && !loadStateCam && !loadStateCam2) {
			MessageBox::Show(this, "Please select a Load Type from the menu", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
		if (loadStateFol) {
			IO::Stream^ myStream;
			OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;

			openFileDialog1->InitialDirectory = ".";  // current folder
			openFileDialog1->Filter = "follower files (*.flwr)|*.flwr|All files (*.*)|*.*";
			openFileDialog1->FilterIndex = 1;  // will show only follower files, but user can choose to show all files
			openFileDialog1->RestoreDirectory = true;

			// get the name of the file user wants
			if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
				// user did not press cancel button nor closed the dialog
				// create filestream for the file
				if ((myStream = openFileDialog1->OpenFile()) != nullptr)
				{
					userFeedbackLabel->Text = openFileDialog1->FileName;

					myStream->Close();
					ifstream inFile;
					inFile.open(StringPlus::convertString(openFileDialog1->FileName));
					if (inFile.is_open()) {
						// create object if needed and read the file

						if (theFollower == nullptr)
							theFollower = new Follower;
						theFollower->readFile(inFile);
						theFollower->setCam(theCam);

						inFile.close();

						userFeedbackLabel->Text += "\n loaded >> followerID =";
						userFeedbackLabel->Text += gcnew String(theFollower->getID().c_str());

						//mainPanel->Refresh();
						resetViewButton_Click(nullptr, nullptr);
						displaySimParameters();
					}
				}
			}
		}
		if (loadStateCam) {
			IO::Stream^ myStream;
			OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;

			openFileDialog1->InitialDirectory = ".";  // current folder
			openFileDialog1->Filter = "cam files (*.cam)|*.cam|All files (*.*)|*.*";
			openFileDialog1->FilterIndex = 1;  // will show only cam files, but user can choose to show all files
			openFileDialog1->RestoreDirectory = true;

			// get the name of the file user wants
			if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
				// user did not press cancel button nor closed the dialog
				// create filestream for the file
				if ((myStream = openFileDialog1->OpenFile()) != nullptr)
				{
					userFeedbackLabel->Text = openFileDialog1->FileName;

					ifstream inFile;
					inFile.open(StringPlus::convertString(openFileDialog1->FileName));
					if (inFile.is_open()) {
						// create object if needed and read the file

						//if (theCam != nullptr)
						//	delete theCam;
						//theCam = new Cam(inFile);

						if (theCam == nullptr)
							theCam = new Cam;
						theCam->readFile(inFile);
						
						inFile.close();

						userFeedbackLabel->Text += "\n loaded >> camID =";
						userFeedbackLabel->Text += gcnew String(theCam->getID().c_str());

						//mainPanel->Refresh();
						resetViewButton_Click(nullptr, nullptr);


					}
					myStream->Close();
				}
				// open file dialog
			}
			CamEditorng27::CamEditor theCamEditor;
			theCamEditor.setCam(theCam);
			checkMaterial();
			//theCamEditor.setSimulator(this);

			theCamEditor.ShowDialog();
			if (theFollower == nullptr) {
				theFollower = new Follower;
				storeSimParameters();
			}
			theFollower->setCam(theCam);

			resetViewButton_Click(nullptr, nullptr);
			mainPanel->Refresh();
		}
		if (loadStateCam2) {
			IO::Stream^ myStream;
			OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;

			openFileDialog1->InitialDirectory = ".";  // current folder
			openFileDialog1->Filter = "cam files (*.cam)|*.cam|All files (*.*)|*.*";
			openFileDialog1->FilterIndex = 1;  // will show only cam files, but user can choose to show all files
			openFileDialog1->RestoreDirectory = true;

			// get the name of the file user wants
			if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
				// user did not press cancel button nor closed the dialog
				// create filestream for the file
				if ((myStream = openFileDialog1->OpenFile()) != nullptr)
				{
					userFeedbackLabel->Text = openFileDialog1->FileName;

					ifstream inFile;
					inFile.open(StringPlus::convertString(openFileDialog1->FileName));
					if (inFile.is_open()) {
						// create object if needed and read the file

						//if (theCam != nullptr)
						//	delete theCam;
						//theCam = new Cam(inFile);

						if (theCam == nullptr)
							theCam = new Cam;
						theCam->readFile(inFile);
						checkMaterial();
						inFile.close();

						userFeedbackLabel->Text += "\n loaded >> camID =";
						userFeedbackLabel->Text += gcnew String(theCam->getID().c_str());

						//mainPanel->Refresh();
						resetViewButton_Click(nullptr, nullptr);


					}
					myStream->Close();
				}
				// open file dialog
			}

			if (theFollower == nullptr) {
				theFollower = new Follower;
				storeSimParameters();
			}
			theFollower->setCam(theCam);

			resetViewButton_Click(nullptr, nullptr);
		}

	}

	private: System::Void saveButton_Click(System::Object^  sender, System::EventArgs^  e) {
		// update parameters
		if (!saveStateCam && !saveStateFol) {
			MessageBox::Show(this, "Please select a Save Type from the menu", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
		storeSimParameters();
		if (saveStateFol) {
			// save file dialog
			IO::Stream^ myStream;
			SaveFileDialog^ saveFileDialog1 = gcnew SaveFileDialog;

			saveFileDialog1->InitialDirectory = ".";  // current folder
			saveFileDialog1->Filter = "follower files (*.flwr)|*.flwr|All files (*.*)|*.*";
			saveFileDialog1->FilterIndex = 1;  // will show only cam files, but user can choose to show all files
			saveFileDialog1->RestoreDirectory = true;

			// get the name of the file user wants
			if (saveFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
				// user did not press cancel button nor closed the dialog
				// create filestream for the file
				if ((myStream = saveFileDialog1->OpenFile()) != nullptr)
				{
					userFeedbackLabel->Text = "Saving file : " + saveFileDialog1->FileName;

					myStream->Close();
					delete myStream;

					ofstream outFile;
					outFile.open(StringPlus::convertString(saveFileDialog1->FileName));
					if (outFile.is_open()) {
						// very unlikely there is no follower since storeSimParameters() 
						// creates one, but just to be safe
						if (theFollower != nullptr)
							theFollower->writeFile(outFile);

						outFile.close();

						userFeedbackLabel->Text += "\n saved ";
					}
				}
			}
		}
		if (saveStateCam) {


			// save file dialog
			IO::Stream^ myStream;
			SaveFileDialog^ saveFileDialog1 = gcnew SaveFileDialog;

			saveFileDialog1->InitialDirectory = ".";  // current folder
			saveFileDialog1->Filter = "cam files (*.cam)|*.cam|All files (*.*)|*.*";
			saveFileDialog1->FilterIndex = 1;  // will show only cam files, but user can choose to show all files
			saveFileDialog1->RestoreDirectory = true;

			// get the name of the file user wants
			if (saveFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
				// user did not press cancel button nor closed the dialog
				// create filestream for the file
				if ((myStream = saveFileDialog1->OpenFile()) != nullptr)
				{
					userFeedbackLabel->Text = "Saving file : " + saveFileDialog1->FileName;

					myStream->Close();
					delete myStream;

					ofstream outFile;
					outFile.open(StringPlus::convertString(saveFileDialog1->FileName));
					if (outFile.is_open()) {
						// if there's an object, write the file
						if (theCam != nullptr)
							theCam->writeFile(outFile);

						outFile.close();

						userFeedbackLabel->Text += "\n saved ";
					}
				}
			}
		}
	}


	private: System::Void viewMotionButton_Click(System::Object^  sender, System::EventArgs^  e) {
		if (theViewer == nullptr || !theViewer->Visible)
			theViewer = gcnew MotionViewer(theFollower);

		if (theViewer->Visible)
			int temp = 1;

		//theViewer->ShowDialog();
		theViewer->Show();

		if (theViewer->Visible) {
			int temp = 1;
			theViewer->setFollower(theFollower);
			theViewer->reloadCharts();
			theViewer->Refresh();
		}

	}

	private: System::Void simulateButton_Click(System::Object^  sender, System::EventArgs^  e) {
		if (theFollower != nullptr)
			theFollower->generateMotion();
		int maxAngle = 360; double interval = System::Convert::ToDouble(simIntervalBox->Text);
		int sleepTime = 50;
		if (mode == RADIANS) {
			interval = interval * 180 / 3.1415;
		}
		else if (mode == RPM) {
			double revspm = Convert::ToDouble(simIntervalBox->Text);
			interval = 360 * revspm / CLOCKS_PER_SEC;
		}
		for (int i = 0; i < maxAngle;) {
			theCam->step(theFollower, interval);
			mainPanel->Refresh();
			i = i + interval;
			Thread^ current = Thread::CurrentThread;
			Thread::Sleep(sleepTime);
		}
	}

	private: System::Void followerHandle_MouseDown(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		currX = e->X;
		currY = e->Y;
		//userFeedbackLabel->Text = "Preparing to move handle";

	}
	private: System::Void followerHandle_MouseMove(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		if (e->Button == System::Windows::Forms::MouseButtons::Left) {
			//int newX = (e->X) + followerHandle->Left - followerHandle->Width / 2;
			//int newY = (e->Y) + followerHandle->Top - followerHandle->Height / 2;
			int newX = (e->X) + followerHandle->Left - currX;
			int newY = (e->Y) + followerHandle->Top - currY;
			//followerHandle->Left = newX;
			//followerHandle->Top = newY;
			if (theFollower != nullptr) {
				Point2D newFollowerStart = getWorldCoords(newX + followerHandle->Width / 2,
					newY + followerHandle->Height / 2);
				theFollower->setStartPoint(newFollowerStart);
				userFeedbackLabel->Text = "Setting follower start to " + newFollowerStart.X.ToString("0.000")
					+ ", " + newFollowerStart.Y.ToString("0.000");
			}
			displaySimParameters();
			mainPanel->Refresh();
			//currX = newX;
			//currY = newY;
			//int temp = 1;
		}
	}

	private: Point2D getScreenCoords(double worldX, double worldY) {
		return { worldX * zoomLevel + panX , worldY * -zoomLevel + panY };
	}

	private: Point2D getWorldCoords(double screenX, double screenY) {
		return { (screenX - panX) / zoomLevel, (screenY - panY) / -zoomLevel };
	}

	private: void setHandlerCoords() {
		if (theFollower == nullptr || theCam == nullptr) {
			followerHandle->Left = -100;
			followerHandle->Top = -100;
		}
		else {
			double currOrientation = theFollower->getOrientation();
			//double camCurrAngle = theCam->getCurrAngle();
			double followerLength = theFollower->getLength();
			Point2D followerLoc = theCam->getTrackPoint(currOrientation);
			followerLength += Line2D::getLength({ 0,0 }, followerLoc);
			currOrientation *= atan(1.) / 45.;
			double handlerX = followerLength * cos(currOrientation);
			double handlerY = followerLength * sin(currOrientation);

			Point2D followerHandlePosition = getScreenCoords(handlerX, handlerY);
			followerHandle->Left = followerHandlePosition.X - followerHandle->Width / 2;
			followerHandle->Top = followerHandlePosition.Y - followerHandle->Height / 2;

		}
	}

			 // this function is typically called within a separate thread
	private: void animateContinuous() {
		if (theCam != nullptr && theFollower != nullptr) {
			//getCamSpeedFromBox();
			double oldCurrAngle = theCam->getCurrAngle();

			// need to figure out how long it takes to regenerate panel
			std::chrono::duration<double> elapsed_milliseconds;
			auto start = std::chrono::system_clock::now();

			mainPanel->Refresh();
			theCam->setCurrAngle(theCam->getCurrAngle() + 0.);
			elapsed_milliseconds = std::chrono::system_clock::now() - start;
			double refreshTime = elapsed_milliseconds.count();

			// now set the angleStep large enough to that we can animate in real time
			double speed = theCam->getCamSpeed() * 360. / 60.;
			double angleStep = refreshTime * 1.2 * speed;

			double secondsPerStep = fabs(angleStep / speed);
			int stepCount = 720 / fabs(angleStep) + 1;

			//angleStep *= speed < 0 ? -1 : 1;  // if speed is negative, make angleStep negative also

			//start animation (for two revolutions)
			auto overallStart = std::chrono::system_clock::now();
			double angleChange = 0;
			start = std::chrono::system_clock::now();
			//while (animationRunning && fabs(theCam->getCurrAngle() - oldCurrAngle) < 720.) {
			//while (stepCount > 0) {
			//	stepCount--;
			while (animationRunning) {
				theCam->setCurrAngle(theCam->getCurrAngle() + angleStep);
				mainPanel->Refresh();
				theViewer->reloadCharts();
				theViewer->Refresh();
				elapsed_milliseconds = std::chrono::system_clock::now() - start;
				Sleep(max(0., secondsPerStep - elapsed_milliseconds.count())*1000.);
				start = std::chrono::system_clock::now();
			}
			std::chrono::duration<double> overallElapsed = std::chrono::system_clock::now() - overallStart;
			userFeedbackLabel->Text = "Completed animation (2 revs): "
				+ overallElapsed.count().ToString("0.0000") + " sec. angleStep=" + angleStep.ToString();

			//animateButton_Click(nullptr, nullptr);
		}
	}
	private: System::Void comboBox1_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
		if (comboBox1->SelectedItem == "Load Cam (with Editor)") {
			loadStateCam = true;
			loadStateCam2 = false;
			loadStateFol = false;
		}
		if (comboBox1->SelectedItem == "Load Follower") {
			loadStateFol = true;
			loadStateCam = false;
			loadStateCam2 = false;
		}
		if (comboBox1->SelectedItem == "Load Cam (no Editor)") {
			loadStateCam = false;
			loadStateCam2 = true;
			loadStateFol = false;
		}
		if (comboBox1->SelectedItem == "Load All") {
			loadStateCam = true;
			loadStateCam2 = false;
			loadStateFol = true;
		}



	}
	private: System::Void comboBox2_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
		if (comboBox2->SelectedItem == "Save Cam") {
			saveStateCam = true;
			saveStateFol = false;
		}
		if (comboBox2->SelectedItem == "Save Follower") {
			saveStateFol = true;
			saveStateCam = false;
		}
		if (comboBox2->SelectedItem == "Save Both") {
			saveStateFol = true;
			saveStateCam = true;
		}


	}
	private: System::Void comboBox3_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
		if (comboBox3->Text == "degrees") {
			mode = DEGREES;
		}
		else if (comboBox3->Text == "radians") {
			mode = RADIANS;
		}
		else if (comboBox3->Text == "rpm") {
			mode = RPM;
		}
		mainPanel->Refresh();
	}

private: System::Void generateCamButton_Click(System::Object^  sender, System::EventArgs^  e) {
	if (theFollower == nullptr) {
		MessageBox::Show(this, "Please select a follower", "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
	}
	else {
		if (theCam != nullptr) {
			delete theCam;
		}
		theCam = new Cam();
		theCam->generateShape();
		//*theShape = theCam->getShape();
		theFollower->setCam(theCam);
		zoomLevel = min(mainPanel->Width, mainPanel->Height) * 0.9 / 2 / theCam->getLargestRadius();
	}
	mainPanel->Refresh();
}
private:System::Void checkMaterial() {
	filled = true;
	if (theCam->material == METAL) {
		camColor = System::Drawing::Color::DimGray;
	}
	else if (theCam->material == WOOD) {
		camColor = System::Drawing::Color::SaddleBrown;
	}
	else if (theCam->material == PLASTIC) {
		camColor = System::Drawing::Color::LightGray;
	}
	else {
		camColor = System::Drawing::Color::DodgerBlue;
		filled = false;
	}
	mainPanel->Refresh();
}
};
}