#include "Cam.h"
#include "StringPlus.h"
#include "Spline2D.h"
#include "ColorConverter.h"

bool Cam::readFile(ifstream & input)
{
	bool foundCam = false; // just to be sure a cam file is being read
	string inString;
	int colonLocation;
	startAngle = 0.;

	while (!input.eof()) {
		getline(input, inString);
		colonLocation = inString.find(":");

		if (inString.find("Cam:") != string::npos) {
			foundCam = true;
		}
		else if (inString.find("camID:") != string::npos) {
			foundCam = true;
			camID = StringPlus::trim(inString.substr(colonLocation + 1));
		}
		else if (inString.find("startAngle:") != string::npos) {
			// assume value is good, may add more robustness later
			startAngle = stod(inString.substr(colonLocation + 1));
		}
		else if (inString.find("Shape") != string::npos) {
			// create the shape object using input stream as constructor parameter
			if (itsShape != nullptr)
				delete itsShape;

			if (inString.find("Spline") != string::npos)
				itsShape = new Spline2D(input);
			else
				itsShape = new Shape2D(input);
		}

	}
	reset();
	return foundCam;
}

void Cam::writeFile(ofstream & output)
{
	output << "Cam:" << endl;

	output << "camID: " << camID << endl;
	output << "startAngle: " << startAngle << endl;
	if (itsShape != nullptr) {
		//output << "Shape: " << endl;
		output << *itsShape;
		//output << "End Shape: " << endl;
	}
}

Point2D Cam::getTrackPoint(double theta)
{
	if (itsShape == nullptr)
		return Point2D();
	else {
		//Point2D rawPoint = itsShape->getIntersection(theta - currAngle);
		//Point2D temp = Line2D::rotate(rawPoint, currAngle);
		return Line2D::rotate(itsShape->getIntersection(theta - currAngle),
			currAngle);
	}
}
double Cam::getLargestRadius()
{
	if (itsShape == nullptr)
		return -1.;
	else
		return itsShape->getMaxRadius();
}

double Cam::getSmallestRadius()
{
	if (itsShape == nullptr)
		return -1.;
	else
		return itsShape->getMinRadius();
}

void Cam::paint(System::Drawing::Graphics ^ g, System::Drawing::Color c, bool filled)
{
	using namespace System::Drawing;
	float centerDiam;
	if (getLargestRadius() == -1)
		centerDiam = 10.;
	else
		centerDiam = getLargestRadius() / 10.;

	Pen centerPen(colorFromHSV(300, 1.0, 1.0), centerDiam / 10.);
	g->DrawEllipse(%centerPen, -centerDiam / 2., -centerDiam / 2.,
		centerDiam, centerDiam);
	g->RotateTransform(currAngle);
	if (itsShape != nullptr)
		itsShape->paint(g, c, filled);
	g->RotateTransform(-currAngle);

}

void Cam::reset()
{
	currAngle = prevAngle = startAngle;
}

void Cam::setID(string newID)
{
	camID = StringPlus::trim(newID);
}

void Cam::setGeometry(Shape2D * newShape)
{
	if (newShape != nullptr) {
		if (itsShape != nullptr)
			delete itsShape;
		itsShape = newShape;
	}
}

void Cam::generateShape()
{
	if (itsShape != nullptr) {
		delete itsShape;

		double currAngle = 0.;
		double currRadius;
		double currX, currY;
		int index = 1;
		itsShape = new Shape2D;
		Follower flwr;
		MotionOutput *motion = flwr.getMotion();
		double max_position = motion->getMaxPosition();
		double stepSize = flwr.getSimInterval();

		while (currAngle < 360.) {
			currRadius = motion->getPosition(currAngle) + max_position;
			currX = currRadius * cos((360 - currAngle) * atan(1.) / 45.);
			currY = currRadius * sin((360 - currAngle) * atan(1.) / 45.);
			itsShape->addPoint({ currX, currY }, index);
			index++;
			currAngle += stepSize;
		}
	}
}

Point2D Cam::step(Follower * aFollower, double interval)
{

	double currPosition;
	currAngle = currAngle + interval;
	return Point2D({ currAngle, currPosition });


}
