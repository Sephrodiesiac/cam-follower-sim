#pragma once
#include <string>
#include "Line2D.h"
#include "Shape2D.h"
#include "Follower.h"

typedef enum CamMaterial {
	WOOD, METAL, PLASTIC
};

using namespace std;
class Axle;
class Follower;

class Cam {
private:
	string camID;
	double startAngle = 0., currAngle = 0., prevAngle = 0.;
	Shape2D *itsShape;
	Axle *itsAxle;
	double camSpeed; // speed of cam, in revs per minute.

public:
	CamMaterial material;
	Cam() {
		itsShape = nullptr;
		itsAxle = nullptr;
	}; 
	// default constructor for the class.

	Cam(ifstream &input) : Cam() {  // delegated constructor
		readFile(input);
	}
	// additional constructor for the class. The constructor needs to instantiate any
	//constituent objects and/or data structures.Takes a pre - created ifstream and uses it to read
	//properties and coordinate information for the cam.

	bool readFile(ifstream &input);
	// overrides all data in the cam object with data read from an
	//input file. Note that the method�s parameter cannot be a string filename because the file may
	//already be in the process of being read.A typical cam input file is attached to this assignment.
	//Note that the order of parameters is NOT important. The point about which the cam rotates has
	//local coordinates of 0, 0. Function returns false if the file being read does not contain the 
	//data for a cam object.

	void writeFile(ofstream &output);
	// writes all the cam parameters and geometry to a file, using the approved format.

	Point2D getTrackPoint(double theta);
	// determines the local coordinates at which the cam
	//profile(or track for future cam types) intersects a ray projected from the cam center point
	//(coordinates 0, 0) along the given theta angle.
	
	double getLargestRadius();
	// calculates and returns the maximum radius of the cam.

	double getSmallestRadius();
	// calculates and returns the minimum radius of the cam.

	void paint(System::Drawing::Graphics ^ g,
		System::Drawing::Color c = System::Drawing::Color::DodgerBlue, bool filled = false);
	// generates the geometry of the cam in its current state on the given
	//geometric space. This function can be tricky, so we will develop it together in lectures.
	
	void reset();
		//sets previous and current angle to the starting position.

	string getID() { return camID; };
	void setID(string newID);

	double getStartAngle() { return startAngle; };
	void setStartAngle(double angle) { startAngle = angle; };

	void setCurrAngle(double angle) { 
		currAngle = angle; 
	};
	double getCurrAngle() { return currAngle; };

	void setCamSpeed(double speed) { camSpeed = speed; };
	double getCamSpeed() { return camSpeed; };

	void setGeometry(Shape2D *newShape);

	void generateShape();

	Point2D step(Follower *aFollower, double interval);
};