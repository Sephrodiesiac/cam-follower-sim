#pragma once
#include <string>
#include "Line2D.h"
#include "MotionOutput.h"
#include "Cam.h"

using namespace std;

class Cam;

class Follower {
protected:
	string followerID;
	double stepSize;
	Cam *itsCam;
	MotionOutput *itsMotion;
	Point2D startPoint, endPoint;
	float length;

public:
	Follower() {
		itsCam = nullptr;
		itsMotion = nullptr;
		stepSize = 10.;
		length = 1.;
	};
	//default constructor for the class.

	Follower(ifstream &input) : Follower() {
		readFile(input);
	};
	// additional constructor for the class. The constructor needs to instantiate
	// any constituent objects and/or data structures.Takes a pre - created ifstream and uses it to read
	// properties and (maybe)coordinate information for the follower.

	bool readFile(ifstream &input);
	// overrides all data in the follower object with data read from an
	// input file. Note that the method�s parameter cannot be a string filename because the file may already
	// be in the process of being read. A typical follower input file is attached to this assignment.Note that
	// the order of parameters is NOT important. Function returns false if the file being read does not contain
	// the data for a follower object.

	void writeFile(ofstream &output);
	// writes all the follower parameters and motion (if any) to a file,
	// using the approved format.

	void setCam(Cam *aCam);
	// sets the cam object to be associated with the follower for subsequent
	// simulations.

	void generateMotion();
	// interacts with the cam object to generate the MotionOutput for a full
	// revolution of the cam.

	void clearMotion(); // removes all motion data from the follower object

	void paint(System::Drawing::Graphics ^g/*, double theta*/);
	// generates the geometry of the follower when the cam is
	// at the given angle, on the given geometric space.

	string getID() { return followerID; };
	Point2D getStartPoint() { return startPoint; };
	Point2D getEndPoint() { return endPoint; };
	double getSimInterval() { return stepSize; };

	void setID(string newID) { followerID = newID; };
	void setStartPoint(Point2D newPoint) { startPoint = newPoint; };
	void setEndPoint(Point2D newPoint) { endPoint = newPoint; };
	void setSimInterval(double newInterval) { stepSize = newInterval; };

	void showMotion(System::Windows::Forms::DataVisualization::Charting::Series ^aSeries, int
		differential = 0);
	// calls the appropriate function to allow for the displaying of motion data in the
	// GUI.The parameter differential indicates if the data needs to be numerically differentiated(0 means
	//	provide motion output directly, 1 means provide velocity, 2 means provide acceleration, etc.)

	double getOrientation();
	double getLength() { return length; };
	MotionOutput *getMotion();
};