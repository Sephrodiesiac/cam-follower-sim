#pragma once
#include <iostream>
#include <fstream>
#include <vector>


using namespace std;

struct PositionData {
	double angle;
	double position;
};

class MotionOutput {
protected:
	vector<PositionData> data;
	

public:

	MotionOutput() { };
	//default constructor for the class.

	MotionOutput(ifstream &input) {
		readFile(input);
	};
	// additional constructor for the class that reads an input file.

	bool readFile(ifstream &input);
	// overrides all data in the MotionOutput object with data read from
	// an input file.Function returns false if the file being read does not 
	// contain the data for a MotionOutput object.

	void writeFile(ostream &output) const;
	// writes all the MotionOutput data to a file, using the approved format.

	friend ostream & operator << (ostream& os, const MotionOutput &aMotion);
	// used to output all the coordinates of a shape.

	bool addData(PositionData newData);
	// adds the position data into the motion being stored. Places
	// the data in sorted order based on angle in the new data(note that angle is to be converted to values of 0
	// to 360 if given otherwise).If position is not positive, data is not added and function returns false.

	double getPosition(double theta);
	// returns the position associated with the angle provided,
	// interpolating as necessary.

	static bool compareData(PositionData left, PositionData right);

	void loadChart(System::Windows::Forms::DataVisualization::Charting::Series ^aSeries, double
		camSpeed, int differential = 0); 
	// provides the information requested (see showMotion()
	// function of Follower class), differentiating as needed.

	double getMaxPosition();

};

