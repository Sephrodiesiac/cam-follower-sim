#pragma once
#include "ColorConverter.h"
#include "Cam.h"

//#include <msclr\marshal_cppstd.h>  //  needed for string conversions
#include "StringPlus.h"  // moved marshal stuff to StringPlus

// using flickerless panel makes the form design view not work.
// to use flickerless panel or allow the design view, use one of these
// in InitComponents() function
//    for design view >>>>    this->mainPanel = (gcnew System::Windows::Forms::Panel());
//    for flickerless >>>>    this->mainPanel = (gcnew FlickerLessPanel());

#include "FlickerLessPanel.h"
#include <array>
#define PI 3.14159265



namespace CamEditorng27 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for CamEditor
	/// </summary>
	public ref class CamEditor : public System::Windows::Forms::Form
	{
	public:
		CamEditor(Cam *aCam) : CamEditor()
		{
			if (theCam != NULL)
				delete theCam;
			theCam = aCam;
		}

		CamEditor(void)
		{
			mouseInPanel = false;

			panX = panY = 300;
			zoomLevel = 2.;

			showTheGrid = false;

			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			mouseInPanel = false;

			panX = panY = 300;
			zoomLevel = 2.;
			showTheGrid = false;


		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~CamEditor()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected:
	private: System::Windows::Forms::Panel^  mainPanel;
	private: System::Windows::Forms::Button^  loadButton;
	private: System::Windows::Forms::Label^  userFeedbackLabel;
	private: System::Windows::Forms::TextBox^  startAngleBox;
	private: System::Windows::Forms::Label^  label2;
			 //double startAngle;
			 //Shape2D *theShape = nullptr;
			 Shape2D *theShape;
			 Cam *theCam = nullptr;
			 double zoomLevel = 1.0;
			 double panX, panY, currX, currY, rotX, rotY;
			 double currAngle = 0;
			 double realAngle = 0;
			 double rad;
			 double rotAngle;
			 double sideA, sideB, sideC;
			 bool showTheGrid, mouseInPanel;
			 float circleSpacing = 4.;
			 Color camColor = Color::DodgerBlue;
			 bool filled = false;

	private: System::Windows::Forms::Button^  loadGeometryButton;

	private: System::Windows::Forms::CheckBox^  gridCheckBox;

	private: System::Windows::Forms::HScrollBar^  angleScrollBar;
	private: System::Windows::Forms::Button^  resetViewButton;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::Button^  saveButton;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  camIDbox;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  minRadiusLabel;
	private: System::Windows::Forms::Label^  maxRadiusLabel;
	private: System::Windows::Forms::VScrollBar^  measureScrollBar;
	private: System::Windows::Forms::Label^  coordLabel;
	private: System::Windows::Forms::CheckBox^  showDotsCheckbox;
	private: System::Windows::Forms::ComboBox^  materialBox;
	private: System::Windows::Forms::Label^  materialLabel;



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->mainPanel = (gcnew System::Windows::Forms::Panel());
			this->coordLabel = (gcnew System::Windows::Forms::Label());
			this->angleScrollBar = (gcnew System::Windows::Forms::HScrollBar());
			this->loadGeometryButton = (gcnew System::Windows::Forms::Button());
			this->loadButton = (gcnew System::Windows::Forms::Button());
			this->userFeedbackLabel = (gcnew System::Windows::Forms::Label());
			this->startAngleBox = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->gridCheckBox = (gcnew System::Windows::Forms::CheckBox());
			this->resetViewButton = (gcnew System::Windows::Forms::Button());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->showDotsCheckbox = (gcnew System::Windows::Forms::CheckBox());
			this->saveButton = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->camIDbox = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->minRadiusLabel = (gcnew System::Windows::Forms::Label());
			this->maxRadiusLabel = (gcnew System::Windows::Forms::Label());
			this->measureScrollBar = (gcnew System::Windows::Forms::VScrollBar());
			this->materialBox = (gcnew System::Windows::Forms::ComboBox());
			this->materialLabel = (gcnew System::Windows::Forms::Label());
			this->mainPanel->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(8, 5);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(126, 16);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Cam Editor Extreme";
			// 
			// mainPanel
			// 
			this->mainPanel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->mainPanel->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(192)), static_cast<System::Int32>(static_cast<System::Byte>(255)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->mainPanel->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->mainPanel->Controls->Add(this->coordLabel);
			this->mainPanel->Location = System::Drawing::Point(139, 29);
			this->mainPanel->Name = L"mainPanel";
			this->mainPanel->Size = System::Drawing::Size(679, 450);
			this->mainPanel->TabIndex = 1;
			this->mainPanel->Paint += gcnew System::Windows::Forms::PaintEventHandler(this, &CamEditor::mainPanel_Paint);
			this->mainPanel->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &CamEditor::mainPanel_MouseDown);
			this->mainPanel->MouseEnter += gcnew System::EventHandler(this, &CamEditor::mainPanel_MouseEnter);
			this->mainPanel->MouseLeave += gcnew System::EventHandler(this, &CamEditor::mainPanel_MouseLeave);
			this->mainPanel->MouseMove += gcnew System::Windows::Forms::MouseEventHandler(this, &CamEditor::mainPanel_MouseMove);
			this->mainPanel->MouseUp += gcnew System::Windows::Forms::MouseEventHandler(this, &CamEditor::mainPanel_MouseUp);
			// 
			// coordLabel
			// 
			this->coordLabel->AutoSize = true;
			this->coordLabel->Location = System::Drawing::Point(604, 13);
			this->coordLabel->Name = L"coordLabel";
			this->coordLabel->Size = System::Drawing::Size(0, 13);
			this->coordLabel->TabIndex = 0;
			// 
			// angleScrollBar
			// 
			this->angleScrollBar->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Left)
				| System::Windows::Forms::AnchorStyles::Right));
			this->angleScrollBar->Location = System::Drawing::Point(139, 7);
			this->angleScrollBar->Maximum = 370;
			this->angleScrollBar->Name = L"angleScrollBar";
			this->angleScrollBar->Size = System::Drawing::Size(678, 15);
			this->angleScrollBar->TabIndex = 5;
			this->angleScrollBar->ValueChanged += gcnew System::EventHandler(this, &CamEditor::angleScrollBar_ValueChanged);
			// 
			// loadGeometryButton
			// 
			this->loadGeometryButton->Location = System::Drawing::Point(10, 64);
			this->loadGeometryButton->Name = L"loadGeometryButton";
			this->loadGeometryButton->Size = System::Drawing::Size(120, 20);
			this->loadGeometryButton->TabIndex = 4;
			this->loadGeometryButton->Text = L"Load Geometry";
			this->loadGeometryButton->UseVisualStyleBackColor = true;
			this->loadGeometryButton->Click += gcnew System::EventHandler(this, &CamEditor::loadGeometryButton_Click);
			// 
			// loadButton
			// 
			this->loadButton->Location = System::Drawing::Point(10, 36);
			this->loadButton->Name = L"loadButton";
			this->loadButton->Size = System::Drawing::Size(120, 20);
			this->loadButton->TabIndex = 3;
			this->loadButton->Text = L"Load Cam File";
			this->loadButton->UseVisualStyleBackColor = true;
			this->loadButton->Click += gcnew System::EventHandler(this, &CamEditor::loadButton_Click);
			this->loadButton->MouseLeave += gcnew System::EventHandler(this, &CamEditor::loadButton_MouseLeave);
			this->loadButton->MouseHover += gcnew System::EventHandler(this, &CamEditor::loadButton_MouseHover);
			// 
			// userFeedbackLabel
			// 
			this->userFeedbackLabel->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->userFeedbackLabel->AutoSize = true;
			this->userFeedbackLabel->Location = System::Drawing::Point(136, 482);
			this->userFeedbackLabel->Name = L"userFeedbackLabel";
			this->userFeedbackLabel->Size = System::Drawing::Size(112, 13);
			this->userFeedbackLabel->TabIndex = 2;
			this->userFeedbackLabel->Text = L"Ready to load cam file";
			// 
			// startAngleBox
			// 
			this->startAngleBox->Location = System::Drawing::Point(10, 183);
			this->startAngleBox->Name = L"startAngleBox";
			this->startAngleBox->Size = System::Drawing::Size(120, 20);
			this->startAngleBox->TabIndex = 3;
			this->startAngleBox->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &CamEditor::startAngleBox_KeyDown);
			this->startAngleBox->Leave += gcnew System::EventHandler(this, &CamEditor::startAngleBox_Leave);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(12, 169);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(59, 13);
			this->label2->TabIndex = 4;
			this->label2->Text = L"Start Angle";
			// 
			// gridCheckBox
			// 
			this->gridCheckBox->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->gridCheckBox->AutoSize = true;
			this->gridCheckBox->Location = System::Drawing::Point(134, 17);
			this->gridCheckBox->Name = L"gridCheckBox";
			this->gridCheckBox->Size = System::Drawing::Size(60, 17);
			this->gridCheckBox->TabIndex = 6;
			this->gridCheckBox->Text = L"Grid (4)";
			this->gridCheckBox->UseVisualStyleBackColor = true;
			this->gridCheckBox->CheckedChanged += gcnew System::EventHandler(this, &CamEditor::gridCheckBox_CheckedChanged);
			// 
			// resetViewButton
			// 
			this->resetViewButton->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->resetViewButton->Location = System::Drawing::Point(3, 12);
			this->resetViewButton->Name = L"resetViewButton";
			this->resetViewButton->Size = System::Drawing::Size(46, 22);
			this->resetViewButton->TabIndex = 7;
			this->resetViewButton->Text = L"Reset";
			this->resetViewButton->UseVisualStyleBackColor = true;
			this->resetViewButton->Click += gcnew System::EventHandler(this, &CamEditor::resetViewButton_Click);
			// 
			// groupBox1
			// 
			this->groupBox1->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Right));
			this->groupBox1->Controls->Add(this->resetViewButton);
			this->groupBox1->Controls->Add(this->showDotsCheckbox);
			this->groupBox1->Controls->Add(this->gridCheckBox);
			this->groupBox1->Location = System::Drawing::Point(614, 482);
			this->groupBox1->Margin = System::Windows::Forms::Padding(0);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Padding = System::Windows::Forms::Padding(0);
			this->groupBox1->Size = System::Drawing::Size(204, 40);
			this->groupBox1->TabIndex = 8;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"View";
			// 
			// showDotsCheckbox
			// 
			this->showDotsCheckbox->Anchor = System::Windows::Forms::AnchorStyles::None;
			this->showDotsCheckbox->AutoSize = true;
			this->showDotsCheckbox->Location = System::Drawing::Point(64, 16);
			this->showDotsCheckbox->Name = L"showDotsCheckbox";
			this->showDotsCheckbox->Size = System::Drawing::Size(48, 17);
			this->showDotsCheckbox->TabIndex = 6;
			this->showDotsCheckbox->Text = L"Dots";
			this->showDotsCheckbox->UseVisualStyleBackColor = true;
			this->showDotsCheckbox->CheckedChanged += gcnew System::EventHandler(this, &CamEditor::showDotsCheckbox_CheckedChanged);
			// 
			// saveButton
			// 
			this->saveButton->Location = System::Drawing::Point(10, 92);
			this->saveButton->Name = L"saveButton";
			this->saveButton->Size = System::Drawing::Size(120, 20);
			this->saveButton->TabIndex = 5;
			this->saveButton->Text = L"Save Cam File";
			this->saveButton->UseVisualStyleBackColor = true;
			this->saveButton->Click += gcnew System::EventHandler(this, &CamEditor::saveButton_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(12, 122);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(42, 13);
			this->label3->TabIndex = 10;
			this->label3->Text = L"Cam ID";
			// 
			// camIDbox
			// 
			this->camIDbox->Location = System::Drawing::Point(10, 136);
			this->camIDbox->Name = L"camIDbox";
			this->camIDbox->Size = System::Drawing::Size(120, 20);
			this->camIDbox->TabIndex = 9;
			this->camIDbox->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &CamEditor::camIDbox_KeyDown);
			this->camIDbox->Leave += gcnew System::EventHandler(this, &CamEditor::camIDbox_Leave);
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(12, 220);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(60, 13);
			this->label4->TabIndex = 4;
			this->label4->Text = L"Min Radius";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(12, 265);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(63, 13);
			this->label5->TabIndex = 11;
			this->label5->Text = L"Max Radius";
			// 
			// minRadiusLabel
			// 
			this->minRadiusLabel->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->minRadiusLabel->Location = System::Drawing::Point(10, 233);
			this->minRadiusLabel->Name = L"minRadiusLabel";
			this->minRadiusLabel->Size = System::Drawing::Size(120, 20);
			this->minRadiusLabel->TabIndex = 12;
			// 
			// maxRadiusLabel
			// 
			this->maxRadiusLabel->BorderStyle = System::Windows::Forms::BorderStyle::FixedSingle;
			this->maxRadiusLabel->Location = System::Drawing::Point(10, 278);
			this->maxRadiusLabel->Name = L"maxRadiusLabel";
			this->maxRadiusLabel->Size = System::Drawing::Size(120, 20);
			this->maxRadiusLabel->TabIndex = 13;
			// 
			// measureScrollBar
			// 
			this->measureScrollBar->Anchor = static_cast<System::Windows::Forms::AnchorStyles>(((System::Windows::Forms::AnchorStyles::Top | System::Windows::Forms::AnchorStyles::Bottom)
				| System::Windows::Forms::AnchorStyles::Right));
			this->measureScrollBar->Location = System::Drawing::Point(824, 34);
			this->measureScrollBar->Maximum = 185;
			this->measureScrollBar->Minimum = -195;
			this->measureScrollBar->Name = L"measureScrollBar";
			this->measureScrollBar->Size = System::Drawing::Size(15, 444);
			this->measureScrollBar->TabIndex = 14;
			this->measureScrollBar->ValueChanged += gcnew System::EventHandler(this, &CamEditor::measureScrollBar_ValueChanged);
			// 
			// materialBox
			// 
			this->materialBox->FormattingEnabled = true;
			this->materialBox->Location = System::Drawing::Point(9, 336);
			this->materialBox->Name = L"materialBox";
			this->materialBox->Size = System::Drawing::Size(121, 21);
			this->materialBox->TabIndex = 15;
			this->materialBox->SelectedIndexChanged += gcnew System::EventHandler(this, &CamEditor::materialBox_SelectedIndexChanged);
			this->materialBox->Items->Add("METAL");
			this->materialBox->Items->Add("WOOD");
			this->materialBox->Items->Add("PLASTIC");
			// 
			// materialLabel
			// 
			this->materialLabel->AutoSize = true;
			this->materialLabel->Location = System::Drawing::Point(13, 322);
			this->materialLabel->Name = L"materialLabel";
			this->materialLabel->Size = System::Drawing::Size(44, 13);
			this->materialLabel->TabIndex = 16;
			this->materialLabel->Text = L"Material";
			// 
			// CamEditor
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::FromArgb(static_cast<System::Int32>(static_cast<System::Byte>(255)), static_cast<System::Int32>(static_cast<System::Byte>(128)),
				static_cast<System::Int32>(static_cast<System::Byte>(255)));
			this->ClientSize = System::Drawing::Size(843, 530);
			this->Controls->Add(this->materialLabel);
			this->Controls->Add(this->materialBox);
			this->Controls->Add(this->measureScrollBar);
			this->Controls->Add(this->angleScrollBar);
			this->Controls->Add(this->maxRadiusLabel);
			this->Controls->Add(this->minRadiusLabel);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->camIDbox);
			this->Controls->Add(this->saveButton);
			this->Controls->Add(this->loadGeometryButton);
			this->Controls->Add(this->loadButton);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->startAngleBox);
			this->Controls->Add(this->userFeedbackLabel);
			this->Controls->Add(this->mainPanel);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->groupBox1);
			this->Name = L"CamEditor";
			this->Text = L"CamEditor";
			this->MouseWheel += gcnew System::Windows::Forms::MouseEventHandler(this, &CamEditor::CamEditor_MouseWheel);
			this->Resize += gcnew System::EventHandler(this, &CamEditor::CamEditor_Resize);
			this->mainPanel->ResumeLayout(false);
			this->mainPanel->PerformLayout();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void mainPanel_Paint(System::Object^  sender, System::Windows::Forms::PaintEventArgs^  e) {

		e->Graphics->TranslateTransform(panX, panY);
		e->Graphics->ScaleTransform(zoomLevel, -zoomLevel);

		e->Graphics->RotateTransform(rotAngle);
		//if (e->X < currX )

		if (showTheGrid)
			showPolarGrid(e->Graphics);

		if (theCam != nullptr) {
			double displayAngle = 360 - angleScrollBar->Value;

			e->Graphics->RotateTransform(displayAngle);
			theCam->paint(e->Graphics, camColor, showDotsCheckbox->Checked);
			e->Graphics->RotateTransform(-displayAngle);
			drawMeasure(e->Graphics);
			theCam->paint(e->Graphics, camColor, filled);
			if (theShape != nullptr) {
				theShape->paint(e->Graphics, camColor, filled);
			}


		}
	}

	private: System::Void loadButton_MouseHover(System::Object^  sender, System::EventArgs^  e) {
		userFeedbackLabel->Text = "Loads a complete cam file (including geometry) from a .cam file.";
	}
	private: System::Void loadButton_MouseLeave(System::Object^  sender, System::EventArgs^  e) {
		userFeedbackLabel->Text = "";
	}

	private: void startAngleBox_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
		if (e->KeyCode == Keys::Enter) {
			userFeedbackLabel->Text = "Just entered " + startAngleBox->Text + " in Start Angle Box";
			getStartAngleFromBox();
		}
	}
	private: System::Void startAngleBox_Leave(System::Object^  sender, System::EventArgs^  e) {
		getStartAngleFromBox();
	}
	private: void getStartAngleFromBox() {

		try {
			double startAngle = Convert::ToDouble(startAngleBox->Text);
			if (theCam == nullptr)
				theCam = new Cam();
			theCam->setStartAngle(startAngle);
			theCam->reset();
			angleScrollBar_ValueChanged(nullptr, nullptr);

		}
		catch (Exception ^excep) {
			MessageBox::Show(this, "Value -> " + startAngleBox->Text + " <- could not be converted to decimal.\n"
				+ excep->Message, "ERROR", MessageBoxButtons::OK, MessageBoxIcon::Error);
		}
	}

	private: void camIDbox_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
		if (e->KeyCode == Keys::Enter) {
			userFeedbackLabel->Text = "Just entered " + camIDbox->Text + " in Cam ID Box";
			getCamIDFromBox();
		}
	}
	private: System::Void camIDbox_Leave(System::Object^  sender, System::EventArgs^  e) {
		getCamIDFromBox();
	}
	private: void getCamIDFromBox() {
		if (theCam == nullptr)
			theCam = new Cam();
		string temp = StringPlus::convertString(camIDbox->Text);
		theCam->setID(temp);
	}

	private: System::Void loadGeometryButton_Click(System::Object^  sender, System::EventArgs^  e) {
		// open file dialog
		IO::Stream^ myStream;
		OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;

		openFileDialog1->InitialDirectory = ".";  // current folder
		openFileDialog1->Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
		openFileDialog1->FilterIndex = 1;  // will show only txt files, but user can choose to show all files
		openFileDialog1->RestoreDirectory = true;

		// get the name of the file user wants
		if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			// user did not press cancel button nor closed the dialog
			// create filestream for the file
			if ((myStream = openFileDialog1->OpenFile()) != nullptr)
			{
				userFeedbackLabel->Text = openFileDialog1->FileName;
				ifstream inFile;

				// need to convert String^ that comes from file dialog to regular string
				//msclr::interop::marshal_context context;
				//std::string standardString = context.marshal_as<std::string>(openFileDialog1->FileName);
				//inFile.open(standardString);

				inFile.open(StringPlus::convertString(openFileDialog1->FileName));

				if (inFile.is_open()) {
					// create new shape and read the file
					Shape2D *newShape = new Shape2D(inFile);

					inFile.close();

					// assign new shape to cam
					if (theCam == nullptr)
						theCam = new Cam();
					theCam->setGeometry(newShape);

					userFeedbackLabel->Text += "\n loaded \n Perimeter=";
					userFeedbackLabel->Text += newShape->perimeter().ToString();
					//cout << newShape << endl;
					resetViewButton_Click(nullptr, nullptr);
					displayCamParameters();
					//mainPanel->Refresh();
				}
				myStream->Close();
			}
		}
	}

	private: System::Void CamEditor_Resize(System::Object^  sender, System::EventArgs^  e) {
		mainPanel->Refresh();
	}

	private: void showPolarGrid(Graphics ^g) {
		Pen ^gridPen = gcnew Pen(colorFromHSV(240, 0.2, 1.0), 0.);

		// draw circles
		int numbCircles = 30.; // change as needed
		//int circleSpacing = 4.; // change as needed
		float currDiam;
		for (int i = 1; i <= numbCircles; i++) {
			currDiam = circleSpacing * i * 2;
			g->DrawEllipse(gridPen, -currDiam / 2., -currDiam / 2., currDiam, currDiam);
		}

		// draw radial lines
		int groupCount = 8; // 4 lines per group
		for (int i = 0; i < groupCount; i++) {
			g->DrawLine(gridPen, 0., 0., numbCircles * circleSpacing, 0.);
			g->RotateTransform(360. / groupCount / 2.);
			g->DrawLine(gridPen, 2 * circleSpacing, 0., numbCircles * circleSpacing, 0.);
			g->RotateTransform(-360. / groupCount / 4.);
			g->DrawLine(gridPen, 4 * circleSpacing, 0., numbCircles * circleSpacing, 0.);
			g->RotateTransform(360. / groupCount / 2.);
			g->DrawLine(gridPen, 4 * circleSpacing, 0., numbCircles * circleSpacing, 0.);
			g->RotateTransform(360. / groupCount / 4.);
		}
	}

	public: System::Void loadButton_Click(System::Object^  sender, System::EventArgs^  e) {
		// open file dialog
		IO::Stream^ myStream;
		OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;

		openFileDialog1->InitialDirectory = ".";  // current folder
		openFileDialog1->Filter = "cam files (*.cam)|*.cam|All files (*.*)|*.*";
		openFileDialog1->FilterIndex = 1;  // will show only cam files, but user can choose to show all files
		openFileDialog1->RestoreDirectory = true;

		// get the name of the file user wants
		if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			// user did not press cancel button nor closed the dialog
			// create filestream for the file
			if ((myStream = openFileDialog1->OpenFile()) != nullptr)
			{
				userFeedbackLabel->Text = openFileDialog1->FileName;

				ifstream inFile;
				inFile.open(StringPlus::convertString(openFileDialog1->FileName));
				if (inFile.is_open()) {
					// create object if needed and read the file

					//if (theCam != nullptr)
					//	delete theCam;
					//theCam = new Cam(inFile);

					if (theCam == nullptr)
						theCam = new Cam;
					theCam->readFile(inFile);

					inFile.close();

					userFeedbackLabel->Text += "\n loaded >> camID =";
					userFeedbackLabel->Text += gcnew String(theCam->getID().c_str());

					//mainPanel->Refresh();
					resetViewButton_Click(nullptr, nullptr);
					displayCamParameters();

				}
				myStream->Close();
			}
		}
	}

	private: System::Void resetViewButton_Click(System::Object^  sender, System::EventArgs^  e) {
		panX = mainPanel->Width / 2;
		panY = mainPanel->Height / 2;
		if (theCam == nullptr) { // use some defaults
			zoomLevel = 2.0;
			circleSpacing = 4.;
		}
		else {
			double referenceSize = min(mainPanel->Width, mainPanel->Height);
			double camSize = theCam->getLargestRadius() * 2.;
			zoomLevel = referenceSize / camSize * 1.0;
			circleSpacing = max(int(camSize / 8), 1) / 2.;
		}
		gridCheckBox->Text = "Grid (" + circleSpacing.ToString("0.##") + ")";
		mainPanel->Refresh();
	}

	private: System::Void gridCheckBox_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		showTheGrid = gridCheckBox->Checked;
		mainPanel->Refresh();
	}

	private: void CamEditor_MouseWheel(Object^ sender, System::Windows::Forms::MouseEventArgs^ e)
	{
		// panel does not take a mousewheel event, so we must handle it at the the level of the form
		// but only if the mouse pointer is inside the panel
		if (mouseInPanel) {

			float zoomStep = 1.2f;  // change as needed for more effect per wheel roll
			float oldZoom = zoomLevel; // will need for resetting panX and panY

			// get actual location of pointer inside the panel (as opposed to the form itself)
			int adjustedX = e->X - mainPanel->Location.X - mainPanel->Margin.Left;
			int adjustedY = e->Y - mainPanel->Location.Y - mainPanel->Margin.Top;

			//e->Delta * SystemInformation::MouseWheelScrollLines / 120
			if (e->Delta < 0) // zoom out
				zoomLevel = zoomLevel / zoomStep;
			else
				zoomLevel = zoomLevel * zoomStep;

			// reset panX and panY such that the coords under the mouse pointer are unchanged
			// i.e., we can zoom in/out on a specific point
			panX = (int)round((adjustedX * (oldZoom - zoomLevel)
				+ panX * zoomLevel) / oldZoom);
			panY = (int)round((adjustedY * (oldZoom - zoomLevel)
				+ panY * zoomLevel) / oldZoom);

			mainPanel->Refresh();

		}
	}

	private: System::Void mainPanel_MouseEnter(System::Object^  sender, System::EventArgs^  e) {
		// only needed because the panel doesn't take a mousewheel event, so we must use
		// the main form instead to detect the use of mousewheel
		mouseInPanel = true;
	}

	private: System::Void mainPanel_MouseLeave(System::Object^  sender, System::EventArgs^  e) {
		// only needed because the panel doesn't take a mousewheel event, so we must use
		// the main form instead to detect the use of mousewheel
		mouseInPanel = false;
	}

	private: System::Void mainPanel_MouseMove(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		if (e->Button == System::Windows::Forms::MouseButtons::Left) {
			rotX = e->X - currX;
			rotY = e->Y - currX;
			//sideA = sqrt(currX*currX + currY * currY);
			//sideB = sqrt((e->X)*(e->X) + (e->Y)*(e->Y));
			//sideC = sqrt(rotX*rotX + rotY * rotY);
			//rotAngle = acos((sideA*sideA + sideB * sideB - sideC * sideC) / (2 * sideA*sideB))*180/PI;
			rotAngle = currAngle + atan2(rotY, rotX) * 180 / PI;
			if (rotAngle < 0)
				rotAngle += 360;
			mainPanel->Refresh();
			currX = e->X; currY = e->Y;
			currAngle = rotAngle;// need to constantly update to allow drag
			


		}
	}

	private: System::Void mainPanel_MouseDown(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		// this function is also part of panning (sets the initial mousewheel click position)
		if (e->Button == System::Windows::Forms::MouseButtons::Left) {
			currX = e->X;
			currY = e->Y;
			rotAngle = 0;
		}
		else if (e->Button == System::Windows::Forms::MouseButtons::Right) {
			float scaledX = (e->X - panX) / zoomLevel;
			float scaledY = (e->Y - panY) / -zoomLevel;
			coordLabel->Text = scaledX.ToString("0.###") + "," + scaledY.ToString("0.###");

			int adjustedX = e->X - 5 - coordLabel->Width;
			int adjustedY = e->Y - 5 - coordLabel->Height;

			coordLabel->Left = adjustedX; coordLabel->Top = adjustedY;

		}

	}

	private: System::Void angleScrollBar_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
		//if (theCam != nullptr) {
		//	theCam->setCurrAngle(theCam->getStartAngle() + 360 - angleScrollBar->Value);
		mainPanel->Refresh();
		//		}
	}

	private: void storeCamParameters() {
		getCamIDFromBox();
		getStartAngleFromBox();
	}

	private: void displayCamParameters() {
		if (theCam != nullptr) {
			camIDbox->Text = gcnew String(theCam->getID().c_str());
			startAngleBox->Text = theCam->getStartAngle().ToString("0.###");
			minRadiusLabel->Text = theCam->getSmallestRadius().ToString("0.###");
			maxRadiusLabel->Text = theCam->getLargestRadius().ToString("0.###");
		}
	}

	private: void drawMeasure(Graphics ^g) {

		if (theCam != nullptr) {
			double displayAngle = angleScrollBar->Value;
			double measureAngle = measureScrollBar->Value;
			Point2D edgePoint = theCam->getTrackPoint(-measureAngle + displayAngle);
			double length = Line2D::getLength(0, 0, edgePoint.X, edgePoint.Y);

			if (length > TOLERANCE) {
				float adj = 1000.;
				length = roundf(length * adj);
				double arrowheadSize = 0.1 * theCam->getSmallestRadius() * adj;
				Pen ^arrowPen = gcnew Pen(Color::Goldenrod, arrowheadSize / 5.);

				// rotate into position and scale up
				g->ScaleTransform(1. / adj, 1. / adj);
				g->RotateTransform(-measureAngle);

				// draw arrow
				g->DrawLine(arrowPen, 0.f, 0.f, length, 0.f);
				g->DrawLine(arrowPen, length - arrowheadSize, arrowheadSize*0.5, length, 0.f);
				g->DrawLine(arrowPen, length - arrowheadSize, -arrowheadSize * 0.5, length, 0.f);

				// write dimension

				// need to scale so that y-axis is down (otherwise text will be upside down)
				g->ScaleTransform(1, -1);

				// Create font and brush.
				System::Drawing::Font^ drawFont = gcnew System::Drawing::Font("Arial", arrowheadSize);
				SolidBrush^ drawBrush = gcnew SolidBrush(arrowPen->Color);

				// Create point for upper-left corner of text.
				PointF drawPoint = PointF(length * 0.4f, arrowheadSize / 3.f);

				// Draw string to screen.
				g->DrawString((length / adj).ToString("0.###"), drawFont, drawBrush, drawPoint);

				// scale back to our normal y-axis is up
				g->ScaleTransform(1, -1);

				// rotate back to normal and scale down
				g->RotateTransform(measureAngle);
				g->ScaleTransform(adj, adj);

			}
		}
	}

	private: System::Void saveButton_Click(System::Object^  sender, System::EventArgs^  e) {
		// update parameters
		storeCamParameters();

		// save file dialog
		IO::Stream^ myStream;
		SaveFileDialog^ saveFileDialog1 = gcnew SaveFileDialog;

		saveFileDialog1->InitialDirectory = ".";  // current folder
		saveFileDialog1->Filter = "cam files (*.cam)|*.cam|All files (*.*)|*.*";
		saveFileDialog1->FilterIndex = 1;  // will show only cam files, but user can choose to show all files
		saveFileDialog1->RestoreDirectory = true;

		// get the name of the file user wants
		if (saveFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
			// user did not press cancel button nor closed the dialog
			// create filestream for the file
			if ((myStream = saveFileDialog1->OpenFile()) != nullptr)
			{
				userFeedbackLabel->Text = "Saving file : " + saveFileDialog1->FileName;

				myStream->Close();
				delete myStream;

				ofstream outFile;
				outFile.open(StringPlus::convertString(saveFileDialog1->FileName));
				if (outFile.is_open()) {
					// if there's an object, write the file
					if (theCam != nullptr)
						theCam->writeFile(outFile);

					outFile.close();

					userFeedbackLabel->Text += "\n saved ";
				}
			}
		}
	}

	private: System::Void measureScrollBar_ValueChanged(System::Object^  sender, System::EventArgs^  e) {
		mainPanel->Refresh();
	}

	private: System::Void mainPanel_MouseUp(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {
		coordLabel->Left = -150;
	}

	private:	 void drawPoint(Graphics ^g, float X, float Y, Color c, int shape) {
		float rectSize = 4.;
		Pen ^thePen = gcnew Pen(c, 0.0);
		if (shape == 1)
			g->DrawRectangle(thePen, X - rectSize / 2., Y - rectSize / 2., rectSize, rectSize);
		else
			g->DrawEllipse(thePen, X - rectSize / 2., Y - rectSize / 2., rectSize, rectSize);
		g->DrawLine(thePen, X - rectSize / 2.f, Y - rectSize / 2.f, X + rectSize / 2.f, Y + rectSize / 2.f);
		g->DrawLine(thePen, X - rectSize / 2.f, Y + rectSize / 2.f, X + rectSize / 2.f, Y - rectSize / 2.f);
	}

	public: void setCam(Cam *aCam) {

		theCam = aCam;
		displayCamParameters();
		resetViewButton_Click(nullptr, nullptr);
		if (theCam->material == METAL) {
			materialBox->Text = "METAL";
			camColor = System::Drawing::Color::DimGray;
		}
		else if (theCam->material = WOOD) {
			materialBox->Text = "WOOD";
			camColor = System::Drawing::Color::SaddleBrown;
		}
		else if (theCam->material = PLASTIC) {
			materialBox->Text == "PLASTIC";
			camColor = System::Drawing::Color::LightGray;
		}
		else
			filled = false;

		mainPanel->Refresh();
	}

	private: System::Void showDotsCheckbox_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
		mainPanel->Refresh();
	}



	private: System::Void materialBox_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
		filled = true;
		if (materialBox->Text == "METAL") {
			theCam->material = METAL;
			camColor = System::Drawing::Color::DimGray;
		}
		else if (materialBox->Text == "WOOD") {
			theCam->material = WOOD;
			camColor = System::Drawing::Color::SaddleBrown;
		}
		else if (materialBox->Text == "PLASTIC") {
			theCam->material = PLASTIC;
			camColor = System::Drawing::Color::LightGray;
		}
		else
			filled = false;
		mainPanel->Refresh();
	}
	};
};


