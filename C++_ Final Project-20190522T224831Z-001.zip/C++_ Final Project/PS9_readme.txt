24-280 PS9 Information
Project done by Thomasjae Garcia(tgarcia), Annette Guo (amguo), Natsuha Omori (nomori)

Features we have added
1. Able to open a cam and follower at the same time. 
   Option to load/save file with/without the editor. 

2. Ability to rotate the cam with mouse drag.

3. Able to switch between degrees, radians, and rpm for animation simulation.

4. Able to change the material of the cam in the Cam Editor.
